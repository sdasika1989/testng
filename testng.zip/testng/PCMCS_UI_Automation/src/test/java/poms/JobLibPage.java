package poms;

import org.openqa.selenium.WebDriver;

public class JobLibPage extends ConsoleJobLibPage{

	public JobLibPage(WebDriver driver){
		super(driver);
	}
}
