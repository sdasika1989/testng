#from selenium import webdriver
#from selenium.webdriver.common.by import By 
#from selenium.webdriver.support.ui import WebDriverWait
#from selenium.webdriver.support import expected_conditions as EC
from utilities.customLogger import logGen
from time import sleep



class LoginPage:
    
    logger = logGen.logggen()
    
    textbox_username_xpath="//input[@name='j_username']|//input[@id='idcs-signin-basic-signin-form-username']|//input[@id='username']"
    textbox_password_xpath="//input[@name='j_password']|//input[@type='password']|//input[@id='password']"
    button_login_xpath="//button[@id='signin']|//span[@class='oj-button-text']|//button[@id='signin']"
    link_actionssettingsdropdown_xpath="//a[@id='cil11']"
    link_signout_xpath="//a[text()='Sign Out']"
    icon_homeicon_xpath="//a[@id='emh1:cil1']"
    
    def __init__(self,driver):
        self.driver = driver
    
    def wait (self, timeout):
        sleep (timeout)
    
    def setUserName(self,username):
        self.driver.find_element_by_xpath(self.textbox_username_xpath).clear()
        self.driver.find_element_by_xpath(self.textbox_username_xpath).send_keys(username)
        
    def setPassword(self,password):
        self.driver.find_element_by_xpath(self.textbox_password_xpath).clear()
        self.driver.find_element_by_xpath(self.textbox_password_xpath).send_keys(password)
        
    def clickLogin(self):
        self.driver.find_element_by_xpath(self.button_login_xpath).click()
        
    def clickSignOut(self):
        self.driver.find_element_by_xpath(self.link_signout_xpath).click()
        
    def clickActionSettingsDropDown(self):
        self.driver.find_element_by_xpath(self.link_actionssettingsdropdown_xpath).click()
        
    def checkElementPresent(self,timeout):
        self.wait(timeout)
        element=self.driver.find_element_by_xpath(self.icon_homeicon_xpath)        
        return element
            
    