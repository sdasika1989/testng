from selenium import webdriver
from pageObjects.LoginPage import LoginPage
from time import sleep
from utilities.readProperties import ReadConfig
from utilities.customLogger import logGen
from utilities.propertiesUtils import PropertiesUtils 
#from testCases.conftest import DriverUtility
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.common.action_chains import ActionChains

class commonComponents:
    
    prop = PropertiesUtils()
    logger = logGen.logggen()
    #gd = DriverUtility()
    browser=ReadConfig.getBrowser()
    profitURL= prop.getProfitURL()
    username=ReadConfig.getUser()
    password=ReadConfig.getPassword()
        
    link_modelscard_xpath="//a[@id='CLOUD_PCM_RULES_4']"
    link_designercard_xpath="//a[@id='CCA104_0_0']"
    link_executioncontrolcard_xpath="//a[@id='CRP94_1_1']"
    link_joblibcard_xpath="//a[@id='CLOUD_PCM_CL11CA214_2_2']"
    link_pov1link_xpath="//a[contains(@id,'pov1Mem')]"
    txtbox_pov1_xpath="//input[contains(@id,'it1::content')]"
    link_pov2link_xpath="//a[contains(@id,'pov2Mem')]"
    txtbox_pov2_xpath="//input[contains(@id,'it1x::content')]"
    link_pov3link_xpath="//a[contains(@id,'pov3Mem')]"
    txtbox_pov3_xpath="//input[contains(@id,'it1y::content')]"
    link_plusicon_xpath="//a[@title=\"Create\"]"
    link_createruleset_xpath="//tr[@title=\"Create Rule Set\"]"
    randomclick_xpath="//a[contains(text(),\"Waterfall Setup\")]"
    link_massEditTab_xpath="//div[@title='Mass Edit']/div/a"
    link_WaterfallSetup_xpath="//a[contains(.,'Waterfall Setup')]"
    button_actionsMassEdit_xpath="//button/span[text()='Actions']"
    
    
    
    def __init__(self,driver):
        self.driver = driver
        
    def wait (self, timeout):
        sleep (timeout)
    
    def clickModelsCard(self):
        self.driver.find_element_by_xpath(self.link_modelscard_xpath).click()
        
    def clickDesignerCard(self):
        self.driver.find_element_by_xpath(self.link_designercard_xpath).click()
        
    def randomClick(self,locator):
        self.driver.find_element_by_xpath(locator).click()
        

    
    def checkElementPresent(self,timeout):
        self.wait(timeout)
        element=self.driver.find_element_by_xpath(self.link_plusicon_xpath)        
        return element
    
    def checkElement(self,timeout,locator):
        self.wait(timeout)
        element=self.driver.find_element_by_xpath(locator)
        return element

    def isDisplayed(self,timeout,locator):
        self.wait(timeout)
        status=self.driver.find_element_by_xpath(locator).is_displayed()
        return status
        
        
    
    
    def getText(self,locator):
        text=self.driver.find_element_by_xpath(locator).text
        return text
    

    
    def setTxtField(self,locator_link,locator,value):
        self.driver.find_element_by_xpath(locator_link).click()
        commonComponents.wait(self, 3)
        #self.driver.find_element_by_xpath(locator).click()
        self.driver.find_element_by_xpath(locator).clear()
        self.driver.find_element_by_xpath(locator).send_keys(value)
        
    def setTxtBoxField(self,locator,value):
        self.driver.find_element_by_xpath(locator).click()
        commonComponents.wait(self, 3)
        self.driver.find_element_by_xpath(locator).clear()
        self.driver.find_element_by_xpath(locator).send_keys(value)
    
    def setTxtBoxFieldWithOutClear(self,locator,value):
        self.driver.find_element_by_xpath(locator).click()
        commonComponents.wait(self, 3)
        #self.driver.find_element_by_xpath(locator).clear()
        self.driver.find_element_by_xpath(locator).send_keys(value)    
    
    def typeEnter(self,timeout,locator,value):
        commonComponents.wait(self, timeout)
        self.driver.find_element_by_xpath(locator).send_keys(value)
        
    def checkEnabled(self,locator):
        
        status = self.driver.find_element_by_xpath(locator).is_enabled()
        return status
    
    def expandReqRuleset(self,ruleSetName):
        reqRuleSetName = "//span[contains(text(),'"+ruleSetName+"')]/parent::span/parent::span/parent::div/span/a[@title='Expand']"
        commonComponents.logger.info(reqRuleSetName)
        commonComponents.randomClick(self, reqRuleSetName)
        
    def hoverElement(self,locator):
        action = ActionChains(self.driver);
        element = self.driver.find_element_by_xpath(locator)
        action.move_to_element(element).perform()
    
    def isSelected(self,locator):
        status = self.driver.find_element_by_xpath(locator).is_selected()
        return status
    
    def checkCheckBoxByRuleName(self,ruleName):
        locator = "//table[@summary='Rules']/tbody/tr[contains(.,'"+ruleName+"')]//input"
        element = self.driver.find_element_by_xpath(locator)
        return element
    
    def clickCheckBoxByRuleName(self,ruleName):
        commonComponents.wait(self, 3)
        reqRule = "//table[@summary='Rules']/tbody/tr[contains(.,'"+ruleName+"')]//input/parent::span/parent::span/parent::span"
        #element = self.driver.find_element_by_xpath(locator)
        commonComponents.logger.info(reqRule)
        commonComponents.randomClick(self, reqRule)

    def clickCheckBoxByRuleNameRuleSet(self,ruleName,ruleSetName):
        commonComponents.wait(self, 3)
        reqRule = "//table[@summary='Rules']/tbody/tr[contains(.,'"+ruleName+"') and contains(.,'"+ruleSetName+"')]//input/parent::span/parent::span/parent::span"
        #element = self.driver.find_element_by_xpath(locator)
        commonComponents.logger.info(reqRule)
        commonComponents.randomClick(self, reqRule)        
        
        
        
    def selectRuleSetByName(self,ruleSetName):
        reqRuleSet="(//span[contains(text(),'"+ruleSetName+"')])[1]"
        commonComponents.logger.info(reqRuleSet)
        commonComponents.randomClick(self, reqRuleSet)
    
    def selectReqRuleByName(self,ruleName):
        reqRule ="//span[contains(text(),'"+ruleName+"')]"
        commonComponents.logger.info(ruleName)
        commonComponents.randomClick(self, reqRule)
        
    def selectReqRuleTab(self,tabOption):    
        reqTab = "//li[contains(.,'"+tabOption+"')]"
        commonComponents.logger.info(tabOption)
        commonComponents.randomClick(self, reqTab)
        
    def selectOptionsMassEdit(self,optionName):
        commonComponents.randomClick(self,self.button_actionsMassEdit_xpath)
        commonComponents.wait(self, 5)
        option_AddMemtoRules="//tr[@title='"+optionName+"']"
        commonComponents.logger.info("******** User is displayed with required option to select and click **************")
        commonComponents.randomClick(self,option_AddMemtoRules)
        commonComponents.logger.info("******** User is clicked on :" + optionName )
        commonComponents.wait(self, 10)
        
    
    def navigateWaterfallScreen(self,driver,testCaseName):
        
        #commonComponents.driver = commonComponents.gd.getDriver(commonComponents.browser)
        driver.get(commonComponents.profitURL)
        driver.maximize_window()
        commonComponents.lp = LoginPage(driver)
        #commonComponents.dp = DesignerPage(driver)
        commonComponents.logger.info("******** User is on login page and entering username and password **************")
        commonComponents.wait(self, 5)
        commonComponents.lp.setUserName(commonComponents.username)
        commonComponents.lp.setPassword(commonComponents.password)
        commonComponents.lp.clickLogin()      
        commonComponents.lp.wait(15)
        if (commonComponents.checkElement(self, 10, self.link_modelscard_xpath)):
            commonComponents.logger.info("******** User successfully logged into the application **************")
        
        else:
            driver.save_screenshot(".\\PCMCS_Jet_DesignerCard\\ScreenShots\\" + testCaseName+".png")
            commonComponents.logger.error("******** User successfully not logged into the application **************")
        
        commonComponents.logger.info("******** User is navigating to the Deisgner Card Waterfall Setup Screen **************")
        commonComponents.clickModelsCard(self)
        commonComponents.wait(self, 5)
        commonComponents.clickDesignerCard(self)
        commonComponents.wait(self, 5)
        commonComponents.logger.info("*** User is navigated to the Designer Card - Waterfall Setup Screen *********")
        if (commonComponents.checkElement(self,10,self.link_plusicon_xpath)):
            commonComponents.logger.info("*** Plus Icon is present on the Waterfall Setup Screen *********")
            assert True
            
        
        else:
            driver.save_screenshot(".\\PCMCS_Jet_DesignerCard\\ScreenShots\\" + testCaseName+".png")
            commonComponents.logger.info("*** Plus Icon is not present on the Waterfall Setup Screen *********")
            driver.quit()
            assert False
        
        commonComponents.logger.info("*** User is selecting POV1 member *********")  
        commonComponents.wait(self, 2)
        commonComponents.setTxtField(self, self.link_pov1link_xpath, self.txtbox_pov1_xpath, 2019)
        commonComponents.randomClick(self,self.randomclick_xpath)
        commonComponents.randomClick(self,self.randomclick_xpath)
        commonComponents.logger.info("*** POV1 member is selected *********")  
        commonComponents.logger.info("*** User is selecting POV2 member *********")
        commonComponents.wait(self, 5)
        commonComponents.setTxtField(self, self.link_pov2link_xpath, self.txtbox_pov2_xpath, "July")
        commonComponents.typeEnter(self, 1, self.txtbox_pov2_xpath, Keys.ENTER)
        commonComponents.randomClick(self,self.randomclick_xpath)
        commonComponents.logger.info("*** POV2 member is selected *********")  
        commonComponents.logger.info("*** User is selecting POV3 member *********")
        commonComponents.wait(self, 4)
        commonComponents.setTxtField(self, self.link_pov3link_xpath, self.txtbox_pov3_xpath, "Actual")
        commonComponents.typeEnter(self, 1, self.txtbox_pov3_xpath, Keys.ENTER)
        commonComponents.logger.info("*** POV3 member is selected *********") 
        
    def navigateMassEditScreen(self):
        commonComponents.wait(self, 10)
        commonComponents.logger.info("*** User is navigating to the Mass Edit Screen *********")
        commonComponents.randomClick(self, self.link_massEditTab_xpath)
        
    def navigatetoWaterfallSetup(self):
        commonComponents.wait(self,6)
        commonComponents.randomClick(self, self.link_WaterfallSetup_xpath)
        commonComponents.wait(self,6)
        
    
    def selectPOVMbrs(self,year,period,scenario):
        
        commonComponents.logger.info("*** User is selecting POV1 member *********")  
        commonComponents.wait(self, 2)
        commonComponents.setTxtField(self, self.link_pov1link_xpath, self.txtbox_pov1_xpath, year)
        commonComponents.randomClick(self,self.randomclick_xpath)
        commonComponents.randomClick(self,self.randomclick_xpath)
        commonComponents.logger.info("*** POV1 member is selected *********")  
        commonComponents.logger.info("*** User is selecting POV2 member *********")
        commonComponents.wait(self, 5)
        commonComponents.setTxtField(self, self.link_pov2link_xpath, self.txtbox_pov2_xpath, period)
        commonComponents.typeEnter(self, 1, self.txtbox_pov2_xpath, Keys.ENTER)
        commonComponents.randomClick(self,self.randomclick_xpath)
        commonComponents.logger.info("*** POV2 member is selected *********")  
        commonComponents.logger.info("*** User is selecting POV3 member *********")
        commonComponents.wait(self, 4)
        commonComponents.setTxtField(self, self.link_pov3link_xpath, self.txtbox_pov3_xpath, scenario)
        commonComponents.typeEnter(self, 1, self.txtbox_pov3_xpath, Keys.ENTER)
        commonComponents.logger.info("*** POV3 member is selected *********")         
            
        
        
        
        
