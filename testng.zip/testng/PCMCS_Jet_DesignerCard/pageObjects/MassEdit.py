from pageObjects.commonComponents import commonComponents
from pageObjects.DesignerPage import DesignerPage
from utilities.customLogger import logGen
from selenium.webdriver.common.keys import Keys

from selenium.common.exceptions import NoSuchElementException




class MassEdit():
    
    logger = logGen.logggen()
   
    text_ExprAddMemberHdng = "//h1[contains(.,'Express Add Member')]"
    text_draftStatus="//span[contains(.,'Draft')]"
    link_addMbrDimSelection_xpath="//input[@title='Balance']/following-sibling::a"
    option_ReqDimX_xpath="//li[contains(.,'X')]"
    txtbox_DimMbrInput_xpath="//input[contains(@id,'it1') and @role]"
    dropdwn_RuleTab_xpath="(//input[contains(@role,'combobox') and @type='text'])[6]"
    option_reqRuleTabSrc_xpath="//li[contains(.,'Source')]"
    textbox_jobComment_xpath="//textarea"
    button_jobRunButton_xpath="//button[contains(.,'Run')]"
    button_jobPopUpOkbutton_xpath="(//button[contains(.,'OK') and @type='button' and contains(@id,':ok')])[1]"
    link_addedSrcDimMbr_xpath="//a[@id='srcMbr_X21' and contains(.,'X21')]"
    link_addedDestDimMbr_xpath="//a[@id='destMbr_X11' and contains(.,'X11')]"
    txt_driverMbrAdded_xpath="//span[contains(.,'X11')]"
    txt_offsetMbrAdded_xpath="//span[contains(.,'X11')]"
    txt_TrgtMbrAdded_xpath="//span[contains(.,'X11')]/parent::a"
    txt_ruleEnableStatus_xpath="//span[@title='Enabled']/parent::div/following-sibling::div/span[contains(text(),'')]"
    txt_errMsgDrvTab_xpath="//span[@title='Only one member allowed for Driver Basis.']|//span[@title='Only one member allowed for Offset.']"
    text_copyRulesPOVHdng="//h1[contains(.,'Copy Rules to Point of View')]"
    text_disableRuleHdng="//div[contains(.,'Confirm Disable Rules') and contains(@id,'ttxt')]"
    txtbox_pov1_xpath="//input[contains(@id,'it1::content')]"
    txtbox_pov2_xpath="//input[contains(@id,'it2::content')]"
    txtbox_pov3_xpath="//input[contains(@id,'it3::content')]"
    txt_copiedRuleSet1_xpath="(//span[contains(text(),'Ruleset 1')])[1]"
    txt_copiedRuleSet2_xpath="(//span[contains(text(),'Ruleset 2')])[1]"
    button_disableYes_xpath="//button[contains(@id,'yes')]"

    def __init__(self,driver):
        self.driver = driver
        
    def disableRulesSelected(self,driver,ruleName1,ruleName2,optionName,testCaseName):
        MassEdit.logger.info("********User is disabling rules from mass edit screen **************")
        cc=commonComponents(driver)
        cc.wait(5)
        if(cc.checkCheckBoxByRuleName(ruleName1) and cc.checkCheckBoxByRuleName(ruleName2)):
            MassEdit.logger.info("********User is displayed with required rules to select for displaying " + ruleName1 + " and " + ruleName2)
            assert True
        else:
            MassEdit.logger.info("********User is not displayed with required rules to select for displaying " + ruleName1 + " and " + ruleName2)
            driver.save_screenshot(".\\PCMCS_Jet_DesignerCard\\ScreenShots\\" + testCaseName+".png")
            driver.quit()
            assert False       
        cc.randomClick(self.text_draftStatus)
        cc.clickCheckBoxByRuleName(ruleName1)  
        MassEdit.logger.info("********User selected rule1***" + ruleName1)
        cc.wait(3)
        cc.randomClick(self.text_draftStatus)
        cc.wait(2)
        cc.clickCheckBoxByRuleName(ruleName2)
        MassEdit.logger.info("********User selected rule2***" + ruleName2)
        cc.wait(5)
        cc.selectOptionsMassEdit(optionName)        
        popUpHdng = cc.getText(self.text_disableRuleHdng)
        if(cc.checkElement(2, self.text_disableRuleHdng) and popUpHdng=="Confirm Disable Rules"):
            MassEdit.logger.info("********User is displayed with  Heading on the pop up *****" + popUpHdng)
            assert True
        else:
            driver.save_screenshot(".\\PCMCS_Jet_DesignerCard\\ScreenShots\\" + testCaseName+".png")
            MassEdit.logger.info("********User is not displayed with Heading on the pop up *****" + popUpHdng)
            driver.quit()
            assert False 
        cc.wait(1)
        cc.randomClick(self.button_disableYes_xpath)  
        cc.wait(3)
        cc.randomClick(self.button_jobPopUpOkbutton_xpath)
    
    def isRulesDisabled(self,driver,ruleSetName,ruleName1,ruleName2,testCaseName):
        MassEdit.logger.info("********User is validating rules are disabled correctly **************")
        cc=commonComponents(driver)
        cc.wait(5)
        cc.selectRuleSetByName(ruleSetName)
        MassEdit.logger.info("*** User selected the rule set to check rules are disabled ****" + ruleSetName)
        cc.wait(8)
        MassEdit.logger.info("*** User is expanding the rule set to check rules are disabled***")
        cc.expandReqRuleset(ruleSetName)
        cc.wait(4)
        MassEdit.logger.info("*** User selecting required rule ***" + ruleName1)
        cc.selectReqRuleByName(ruleName1)
        cc.wait(5)
        enableStatus=cc.getText(self.txt_ruleEnableStatus_xpath)
        if (enableStatus=="No"):
            MassEdit.logger.info("*** After disabling rule is in disabled status ***" + enableStatus)
            assert True
        else:
            driver.save_screenshot(".\\PCMCS_Jet_DesignerCard\\ScreenShots\\" + testCaseName+".png")
            MassEdit.logger.info("*** After disabling rule is not in disabled status ***" + enableStatus)
            driver.quit()
            assert False   
        cc.selectReqRuleByName(ruleName2)
        cc.wait(5)
        enableStatus=cc.getText(self.txt_ruleEnableStatus_xpath)
        if (enableStatus=="No"):
            MassEdit.logger.info("*** After disabling rule is in disabled status ***" + enableStatus)
            assert True
            driver.quit()
        else:
            driver.save_screenshot(".\\PCMCS_Jet_DesignerCard\\ScreenShots\\" + testCaseName+".png")
            MassEdit.logger.info("*** After disabling rule is not in disabled status ***" + enableStatus)
            driver.quit()
            assert False                
        
            
    def copyRulestoNewPOV(self,driver,ruleName1,ruleName2,ruleSetName,optionName,jobComment,testCaseName):
        MassEdit.logger.info("********User is copying rules into new pov **************")
        cc=commonComponents(driver)
        cc.wait(5)
        if(cc.checkCheckBoxByRuleName(ruleName1) and cc.checkCheckBoxByRuleName(ruleName2)):
            MassEdit.logger.info("********User is displayed with required rules to select for copying into new pov: " + ruleName1 + " and " + ruleName2)
            assert True
        else:
            MassEdit.logger.info("********User is not displayed with required rules to select for copying into new pov: " + ruleName1 + " and " + ruleName2)
            driver.save_screenshot(".\\PCMCS_Jet_DesignerCard\\ScreenShots\\" + testCaseName+".png")
            driver.quit()
            assert False
        cc.randomClick(self.text_draftStatus)
        cc.clickCheckBoxByRuleName(ruleName1)  
        MassEdit.logger.info("********User selected rule1***" + ruleName1)
        cc.wait(3)
        cc.randomClick(self.text_draftStatus)
        cc.wait(2)
        cc.clickCheckBoxByRuleNameRuleSet(ruleName2, ruleSetName)
        MassEdit.logger.info("********User selected rule2***" + ruleName2)
        cc.wait(5)
        cc.selectOptionsMassEdit(optionName)
        popUpHdng = cc.getText(self.text_copyRulesPOVHdng)
        if(cc.checkElement(2, self.text_copyRulesPOVHdng) and popUpHdng=="Copy Rules to Point of View"):
            MassEdit.logger.info("********User is displayed with  Heading on the pop up *****" + popUpHdng)
            assert True
        else:
            driver.save_screenshot(".\\PCMCS_Jet_DesignerCard\\ScreenShots\\" + testCaseName+".png")
            MassEdit.logger.info("********User is not displayed with Heading on the pop up *****" + popUpHdng)
            driver.quit()
            assert False     
        MassEdit.logger.info("*** User is selecting POV1 member *********")  
        cc.wait(2)
        cc.setTxtBoxField(self.txtbox_pov1_xpath, 2019)
        cc.typeEnter(1, self.txtbox_pov1_xpath, Keys.ENTER)
        MassEdit.logger.info("*** POV1 member is selected *********")  
        MassEdit.logger.info("*** User is selecting POV2 member *********")
        cc.wait(3)
        cc.setTxtBoxField(self.txtbox_pov2_xpath, "January")
        cc.typeEnter(1, self.txtbox_pov2_xpath, Keys.ENTER)
        MassEdit.logger.info("*** POV2 member is selected *********")  
        MassEdit.logger.info("*** User is selecting POV3 member *********")
        cc.wait(3)
        cc.setTxtBoxField(self.txtbox_pov3_xpath, "Actual")
        cc.typeEnter(1, self.txtbox_pov3_xpath, Keys.ENTER)
        MassEdit.logger.info("*** POV3 member is selected *********") 
        cc.wait(3)
        cc.setTxtBoxField(self.textbox_jobComment_xpath, jobComment)
        cc.wait(2)
        cc.randomClick(self.button_jobRunButton_xpath)
        cc.wait(2)       
        cc.randomClick(self.button_jobPopUpOkbutton_xpath)    
    
    def isRulesPresent(self,driver,year,period,scenario,ruleSetName1,ruleName1,ruleSetName2,ruleName2,testCaseName):
        
        MassEdit.logger.info("********User is validating rules are copied correctly **************")
        cc=commonComponents(driver)
        #dp = DesignerPage(driver)
        cc.navigatetoWaterfallSetup()     
        cc.selectPOVMbrs(year, period, scenario) 
        cc.wait(5)
        if (cc.checkElement(2, self.txt_copiedRuleSet1_xpath) and cc.checkElement(2, self.txt_copiedRuleSet2_xpath)):
            MassEdit.logger.info("********Copied Rule Sets are displaying correctly **************") 
            assert True
        else:
            driver.save_screenshot(".\\PCMCS_Jet_DesignerCard\\ScreenShots\\" + testCaseName+".png")
            MassEdit.logger.info("********Copied Rule Sets are not displaying correctly **************")
            driver.quit()
            assert False 
        cc.selectRuleSetByName(ruleSetName1)
        MassEdit.logger.info("*** User selected the rule set to check rule is copied ****" + ruleSetName1)
        cc.wait(8)
        MassEdit.logger.info("*** User is expanding the rule set to check the copied rule***")
        cc.expandReqRuleset(ruleSetName1)
        cc.wait(4)
        MassEdit.logger.info("*** User selecting required rule ***" + ruleName1)
        cc.selectReqRuleByName(ruleName1)
        cc.wait(8)
        enableStatus=cc.getText(self.txt_ruleEnableStatus_xpath)
        if (enableStatus=="Yes"):
            MassEdit.logger.info("*** After copying rule is in enabled status ***" + enableStatus)
            assert True
        else:
            driver.save_screenshot(".\\PCMCS_Jet_DesignerCard\\ScreenShots\\" + testCaseName+".png")
            MassEdit.logger.info("*** After copying rule is not in enabled status ***" + enableStatus)
            driver.quit()
            assert False        
        cc.selectRuleSetByName(ruleSetName2)
        MassEdit.logger.info("*** User selected the rule set to check rule is copied ****" + ruleSetName2)
        cc.wait(8)
        MassEdit.logger.info("*** User is expanding the rule set to check the copied rule***")
        cc.expandReqRuleset(ruleSetName2)
        cc.wait(4)
        MassEdit.logger.info("*** User selecting required rule ***" + ruleName2)
        cc.selectReqRuleByName(ruleName2)
        cc.wait(8)
        enableStatus=cc.getText(self.txt_ruleEnableStatus_xpath)
        if (enableStatus=="Yes"):
            MassEdit.logger.info("*** After copying rule is in enabled status ***" + enableStatus)
            assert True
            driver.quit()
        else:
            driver.save_screenshot(".\\PCMCS_Jet_DesignerCard\\ScreenShots\\" + testCaseName+".png")
            MassEdit.logger.info("*** After copying rule is not in enabled status ***" + enableStatus)
            driver.quit()
            assert False         
        
        
    def createAddMemJob(self,driver,ruleName,testCaseName,optionName,dim1Mbr,tabOption,jobComment,addAnotherMbr,dim2Mbr):
        MassEdit.logger.info("********Add Member Job Creation Process is Starting **************")
        cc=commonComponents(driver)
        cc.wait(8)
        if(cc.checkCheckBoxByRuleName(ruleName)):
            MassEdit.logger.info("********User is displayed with required rule to select for adding new member: " + ruleName)
            assert True
        else:
            MassEdit.logger.info("********User is not displayed with required rule to select for adding new member: " + ruleName)
            driver.save_screenshot(".\\PCMCS_Jet_DesignerCard\\ScreenShots\\" + testCaseName+".png")
            driver.quit()
            assert False
        cc.randomClick(self.text_draftStatus)
        cc.clickCheckBoxByRuleName(ruleName)
        cc.wait(8)
        cc.selectOptionsMassEdit(optionName)
        popUpHdng = cc.getText(self.text_ExprAddMemberHdng)
        if(cc.checkElement(2, self.text_ExprAddMemberHdng) and popUpHdng=="Express Add Member"):
            MassEdit.logger.info("********User is displayed with Express Add Member Heading on the pop up *****")
            assert True
        else:
            driver.save_screenshot(".\\PCMCS_Jet_DesignerCard\\ScreenShots\\" + testCaseName+".png")
            MassEdit.logger.info("********User is not displayed with Express Add Member Heading on the pop up *****")
            driver.quit()
            assert False
        cc.wait(4)
        cc.randomClick(self.link_addMbrDimSelection_xpath)
        cc.wait(3)
        cc.randomClick(self.option_ReqDimX_xpath)
        MassEdit.logger.info("********User is entering required dimension member *****")
        cc.wait(2)
        cc.randomClick(self.text_ExprAddMemberHdng)
        cc.setTxtBoxField(self.txtbox_DimMbrInput_xpath, dim1Mbr)
        cc.typeEnter(1, self.txtbox_DimMbrInput_xpath, Keys.ENTER)
        MassEdit.logger.info("********User ENTERED required dimension member1 *****")
        cc.wait(3)
        if(addAnotherMbr=="YES"):
            cc.wait(4)
            cc.setTxtBoxField(self.txtbox_DimMbrInput_xpath, dim2Mbr)
            cc.typeEnter(1, self.txtbox_DimMbrInput_xpath, Keys.ENTER)
            MassEdit.logger.info("********User ENTERED required dimension member2 *****")
            cc.wait(3)
        cc.randomClick(self.dropdwn_RuleTab_xpath)
        cc.wait(2)
        cc.selectReqRuleTab(tabOption)
        MassEdit.logger.info("********User selected required rule tab to add the dim mbr *****" + tabOption)
        cc.setTxtBoxField(self.textbox_jobComment_xpath, jobComment)
        cc.wait(3)
        cc.randomClick(self.button_jobRunButton_xpath)
        
        cc.wait(4)
        if(addAnotherMbr=="YES"):
            errMsg=cc.getText(self.txt_errMsgDrvTab_xpath)
            if(errMsg=="Only one member allowed for Driver Basis." or errMsg=="Only one member allowed for Offset."):
                MassEdit.logger.info("********User is displayed expected error message***" +errMsg )
                driver.quit()
                assert True
            else:
                driver.save_screenshot(".\\PCMCS_Jet_DesignerCard\\ScreenShots\\" + testCaseName+".png")
                MassEdit.logger.info("********User is not displayed expected error message***")
                driver.quit()
                assert False
        else:
            cc.randomClick(self.button_jobPopUpOkbutton_xpath)
    
    def isMemberPresent(self,driver,ruleSetName,ruleName,testCaseName,srcdest,srcMbrVerifiction):
        cc=commonComponents(driver)
        dp = DesignerPage(driver)
        cc.navigatetoWaterfallSetup()
        cc.selectRuleSetByName(ruleSetName)
        MassEdit.logger.info("*** User selected the rule set to check the member addition is correct ****" + ruleSetName)
        cc.wait(8)
        MassEdit.logger.info("*** User is clicking on the required rule to check the member addition***")
        cc.expandReqRuleset(ruleSetName)
        cc.wait(4)
        MassEdit.logger.info("*** User is selecting required rule ***" + ruleName)
        cc.selectReqRuleByName(ruleName)
        cc.wait(8)
        enableStatus=cc.getText(self.txt_ruleEnableStatus_xpath)
        if (enableStatus=="Yes"):
            MassEdit.logger.info("*** After adding new member rule is still in enable status ***" + enableStatus)
            assert True
        else:
            driver.save_screenshot(".\\PCMCS_Jet_DesignerCard\\ScreenShots\\" + testCaseName+".png")
            MassEdit.logger.info("*** After adding new member rule is in disable status ***" + enableStatus)
            driver.quit()
            assert False
        cc.wait(7)
        cc.randomClick(dp.link_editButton_xpath)
        cc.wait(15)        
        if (srcdest=="YES"):
            cc.randomClick(dp.link_srcdestTab_xpath)
            MassEdit.logger.info("*** User navigated to the src/dest tab of the alloc rule***")
            cc.wait(10)
            cc.randomClick(dp.link_dim1Rule_xpath)
            cc.wait(8)
            if(srcMbrVerifiction=="YES"):
                if(cc.checkElement(2, self.link_addedSrcDimMbr_xpath)):
                    MassEdit.logger.info("***Member Added correctly in src through express edit***")
                    return True
                else:
                    driver.save_screenshot(".\\PCMCS_Jet_DesignerCard\\ScreenShots\\" + testCaseName+".png")
                    MassEdit.logger.info("***Member is not Added correctly in src through express edit***")
                    return False
            else:
                if(cc.checkElement(2, self.link_addedDestDimMbr_xpath)):
                    MassEdit.logger.info("***Member Added correctly in dest through express edit***")
                    return True
                else:
                    driver.save_screenshot(".\\PCMCS_Jet_DesignerCard\\ScreenShots\\" + testCaseName+".png")
                    MassEdit.logger.info("***Member is not Added correctly in dest through express edit***")
                    return False
                
        elif(srcdest=="NO"):
            cc.randomClick(dp.link_driverTab_xpath)
            cc.wait(10)
            MassEdit.logger.info("*** User navigated to the driver basis tab of the alloc rule***")
            #cc.randomClick(dp.link_dim1RuleCC_xpath)
            if(cc.checkElement(10, self.txt_TrgtMbrAdded_xpath)):
                MassEdit.logger.info("*** Member Added correctly in driver basis tab through express edit***")
                return True
            else:
                driver.save_screenshot(".\\PCMCS_Jet_DesignerCard\\ScreenShots\\" + testCaseName+".png")
                MassEdit.logger.info("*** Member is not Added correctly in driver basis tab through express edit***")
                return False
        
        elif(srcdest=="TRGT"):
            cc.randomClick(dp.link_trgtTab_xpath)
            MassEdit.logger.info("*** User navigated to the Trgt tab of the custom rule***")
            if(cc.checkElement(10, self.txt_driverMbrAdded_xpath)):
                MassEdit.logger.info("*** Member Added correctly in Target tab through express edit***")
                return True
            else:
                driver.save_screenshot(".\\PCMCS_Jet_DesignerCard\\ScreenShots\\" + testCaseName+".png")
                MassEdit.logger.info("*** Member is not Added correctly in Target tab through express edit***")
                return False                
        else:
            cc.randomClick(dp.link_offsetTab_xpath)            
            MassEdit.logger.info("*** User navigated to the Offset tab of the alloc rule***")
            try:
                status = bool(cc.isDisplayed(10, self.txt_offsetMbrAdded_xpath))
                MassEdit.logger.info(status)
                if(status):
                    MassEdit.logger.info("*** Member Added correctly in Offset tab through express edit***")
                    return True
                else:
                    driver.save_screenshot(".\\PCMCS_Jet_DesignerCard\\ScreenShots\\" + testCaseName+".png")
                    MassEdit.logger.info("*** Member is not Added correctly in Offset tab through express edit***")
                    return False
            except NoSuchElementException:
                    driver.save_screenshot(".\\PCMCS_Jet_DesignerCard\\ScreenShots\\" + testCaseName+".png")
                    MassEdit.logger.info("*** Member is not Added correctly in Offset tab through express edit***")
                    return False
                
            
            
            
            
            