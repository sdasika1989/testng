from pageObjects.commonComponents import commonComponents
from utilities.customLogger import logGen
from selenium.webdriver.common.keys import Keys
#import selenium.webdriver.support.ui as ui
#from selenium.webdriver.common.action_chains import ActionChains

class DesignerPage:
    
    
    logger = logGen.logggen()
    link_plusicon_xpath="//a[@title=\"Create\"]"
    link_createruleset_xpath="//tr[@title=\"Create Rule Set\"]"
    item_ruleSet_xpath="//tr[@title=\"Create Rule Set\"]"
    item_allocRule_xpath="//tr[@title=\"Create Allocation Rule\"]"
    item_customRule_xpath="//tr[@title=\"Create Custom Rule\"]"
    txtbox_ruleSetField_xpath="//input[@id='ruleset|input']"
    txtbox_ruleSetDesc_xpath="//*[@id='rulesetdescription|input']"
    txtbox_allocRuleField_xpath="//input[@id='ruleName|input']"
    txtbox_allocRuleDesc_xpath="//*[@id='ruleDescription|input']"
    checkbox_enableRuleSet_xpath="//input[@id='ruleSetEnabled|cb']"
    checkbox_enableRule_xpath="//input[@id='ruleEnabled|cb']"
    text_definitionHeading_xpath="//a[@title='Identifying information about the Rule Set.']"
    text_dimensionHeading_xpath="//a[@title='Context dimension member selections']"
    text_createRuleSet_xpath="//span[contains(text(),'Create Rule Set')]"
    button_addRSCDimension_xpath="//span[@id='ui-id-13']|//span[contains(text(),'Add Dimensions')]|//span[contains(text(),'Add Dimensions')]/parent::div/parent::button"
    link_rscDimSelection_xpath="(//a/span[contains(text(),'R')])[1]"
    label_rscDimMemSelected_xpath="//label[@id='RDimension|label']"
    link_rscDimMemSelection_xpath="//a[@id='RCtxSelMbr']"
    txtbox_rscDimMemSelection_xpath="//input[@id='RAddMember|input']"
    button_rscDimSaveClose_xpath="//button/div/span[contains(text(),'Save and Close')]"
    text_createdRuleSet_xpath="//img[@title='Rule Set']/following-sibling::span[contains(text(),'ruleSet1')]"
    text_createdRuleSet1_xpath="//img[@title='Rule Set']/following-sibling::span[contains(text(),'ruleSet2')]"
   
    #button_ruleSetOk_xpath="//*[@id='okButton']//button[@class='oj-button-button oj-component-initnode']"
    button_ruleSetInfoOk_xpath="//*[@id='okButton']"
    label_existingRuleSet_xpath= "(//span[contains(text(),'Ruleset 1')])[1]"
    label_existingRuleSet2_xpath="(//span[contains(text(),'Ruleset 2')])[1]"
    label_existingRuleSet3_xpath="(//span[contains(text(),'Ruleset 3')])[1]"
    label_copiedRuleSet_xpath="(//span[contains(text(),'Copied Rule Set')])[1]"
    label_copiedRuleSet1_xpath="(//span[contains(text(),'Copied Rule Set1')])[1]"
    link_copyImage_xpath="//a[@title='Copy']"
    label_copyRuleHdng_xpath="//h1[contains(text(),'Copy Rule')]"
    label_copyRuleSetHeading_xpath="//div[@title='Copy Rule Set']/h1"
    txtbox_copyRuleSetName_xpath="//input[@id='zr0:0:zt0:0:zc0:0:r7:1:it1::content']"
    txtbox_copyRuleName_xpath="//input[@id='zr0:0:zt0:0:zc0:0:r6:1:it1::content']"
    txtbox_prefixRuleName_xpath="//input[@id='zr0:0:zt0:0:zc0:0:r7:1:it2::content']"
    txtbox_amountField_xpath="//input[@id='amount|input']"
    button_copyRuleSetOk_xpath="//button[@title='OK']"
    button_duplicateRuleEOkBtn_xpath="//button[contains(@id,'skyrosError::ok')]"
    checkbox_copyRulesChkBox_xpath="//input[@id='zr0:0:zt0:0:zc0:0:r7:1:sbc2::content']/following-sibling::label"
    link_editButton_xpath="//a[@title='Edit']"
    label_editRuleSettxt="//span[@id='createRSHdrLbl']"
    label_enableStatustxt="//span[contains(text(),'No')]"
    label_ruleEnbleStatus="//span[@title='Enabled']/parent::div/following-sibling::div/span[contains(text(),'No')]"
    link_deleteButton_xpath="//a[@title='Delete']"
    label_deleteRuleSetTxt_xpath="//td[@id=\"zr0:0:zt0:0:zc0:0:d3::contentContainer\"]"
    label_delteRuleTxt_xpath="//td[contains(text(),'Deleting this rule will also delete')]"
    button_deleteRuleSetYes_xpath="//button[@id='zr0:0:zt0:0:zc0:0:d3::yes']"
    image_helpIcon_xpath="//oj-menu-button[@title='Help']"
    #image_helpIcon_xpath="//span[@slot='startIcon']/parent::div/parent::button/parent::oj-menu-button"
    link_helpLink_xpath="(//span[contains(text(),'Help')]/parent::a)[1]"
    link_helpOnThis_xpath="(//span[contains(text(),'Help')]/parent::a)[2]"
    label_helpPageText="//h2[contains(text(),'Table of Contents')]"
    link_dimMemSearchIcon_xpath="//a[@title='Invoke Member Selector']"
    label_memSelectorText_xpath="//span[contains(text(),'Member Selector')]"
    txtbox_dimMemInputSearch_xpath="//input[contains(@name,'filterSearchTxt')]"
    link_dimMemSelecorSearchIcon_xpath="(//img[@title='Search' and @alt='Search']/parent::a[@title='Search'])[2]"
    link_reqDimMemSelection_xpath="//a[@title='Add Member R21']"
    link_reqTrgtDimMemSelection_xpath="//a[@title='Add Member Y11']"
    link_reqDim1SrcSelection_xpath="//a[@title='Add Member X1']"
    link_reqDim1DestSelection_xpath="//a[@title='Add Member X12']"
    button_memSelectorOkButton_xpath="(//button[contains(text(),'OK')])[1]"
    button_memSelectorRuleOkBtn_xpath="//button[contains(@id,'memSelOkBtn')]"
    label_createAllocRuleHdng_xpath="//span[contains(text(),'Create Allocation Rule')]"
    label_createCustomRuleHdng_xpath="//span[contains(text(),'Create Custom Rule')]"
    dropDown_allocatedAmount_xpath="//input[@id='allocAmountTypeCombo|input']"
    txt_defaultAllocatedAmount_xpath="//div[@aria-selected='true']"
    label_amountField_xpath="//label[@id='amountLbl|label']"
    option_noneAllocAmount_xpath="//li/div/span[contains(text(),'None')]"
    option_currencyAllocAmount_xpath="//li/div/span[contains(text(),'Currency')]"
    option_percentageAllocAmount_xpath="//li/div/span[contains(text(),'Percentage')]"
    link_srcdestTab_xpath="//a[@title='Define Source and Destination members for the rule']"
    link_trgtTab_xpath="//a[@title='Rule Target']"
    txtbox_formulaTextBx_xpath="//textarea[@id='formula|input']"
    button_validateFormula_xpath="//span[contains(text(),'Validate')]/parent::div/parent::button"
    txt_errMsgValidationFormula_xpath="//span[contains(text(),'Formula is needed for Custom Calculation rules')]"
    txt_errMsg1Custom_xpath="//span[contains(text(),'Dimension Y in the Target tab for Rule customRule3 does not have a member selected.')]"
    txt_errMsg2Custom_xpath="//span[contains(text(),'Dimension X in the Target tab for Rule customRule3 does not have a member selected.')]"
    txt_errMsgValidationAlloc_xpath="//span[contains(text(),'Warning:  Rule cannot be enabled because it has failed Validations.  The validation failures are as follows: ')]"
    txt_errormsg1Alloc_xpath="//span[contains(text(),'Dimension Y in the Destination for Rule allocRule does not have a member selected.')]"
    txt_errormsg2Alloc_xpath="//span[contains(text(),'Dimension X in the Destination for Rule allocRule does not have a member selected.')]"
    txt_errormsg3Alloc_xpath="//span[contains(text(),'Dimension Y in the Source for Rule allocRule does not have a member selected.')]"
    txt_errormsg4Alloc_xpath="//span[contains(text(),'Dimension X in the Source for Rule allocRule does not have a member selected.')]"
    link_dim1Rule_xpath="//a[@role=\"button\"]/following-sibling::div/div/div/span[contains(text(),\"X\")]"
    link_dim2Rule_xpath="//span[contains(text(),\"Y\") and @title='Y']/parent::div/parent::div/parent::div/parent::div/a"
    link_dim3Rule_xpath="//a[@role=\"button\"]/following-sibling::div/div/div/span[contains(text(),\"Z\")]"
    link_dim4Rule_xpath="//a[@role=\"button\"]/following-sibling::div/div/div/span[contains(text(),\"W\")]"
    link_dim1SrcLink_xpath="//a[@id='X_addMbrLinkSrc']"
    link_dim1SrcAddedLink_xpath="//a[@id='srcMbr_X1']"
    link_dim2SrcLink_xpath="//a[@id='Y_addMbrLinkSrc']"
    link_dim3SrcLink_xpath="//a[@id='Z_addMbrLinkSrc']"
    link_dim4SrcLink_xpath="//a[@id='W_addMbrLinkSrc']"
    link_dim1DestLink_xpath="//a[@id='X_addMbrLinkDest']"
    link_dim2DestLink_xpath="//a[@id='Y_addMbrLinkDest']"
    link_dim3DestLink_xpath="//a[@id='Z_addMbrLinkDest']"
    link_dim4DestLink_xpath="//a[@id='W_addMbrLinkDest']"
    link_addDim1MemTrgt_xpath="//a[@title='X1']"
    link_manageFilters_xpath="//span[contains(text(),'Manage Filters')]/parent::a"
    txt_mngFilterHdng_xpath="//span[@id='manageFiltersHdrLbl']"
    button_addFilters_xpath="//span[contains(text(),'Add')]/parent::div/parent::button"
    txtbox_dimFilter_xpath="//input[@id='value0|input']"
    txtbox_dimFilter1_xpath="//input[@id='value1|input']"
    button_saveFiltersOk_xpath="//*[@id='saveFiltersBtn']"
    button_dupErrFilterOk_xpath="//*[@id='okButton']"
    button_dupFilterRemove_xpath="//*[@id='removeBtn1']"
    txt_errDuplicateFilers_xpath="//span[contains(@class,'preserve-whitespace')]"
    link_addedFilterDim1Trgt_xpath="//a[@title='X1 (Name = X11)']"
    link_dim1RuleCC_xpath="//a[@title=\"X Dimension Target Actions\"]/parent::div/parent::div/parent::div/a"
    link_dim2RuleCC_xpath="//a[@title=\"Y Dimension Target Actions\"]/parent::div/parent::div/parent::div/a"
    txtbox_dim1SrcInput_xpath="//input[@id='X_addMemberComboSrc|input']"
    txtbox_dim2SrcInput_xpath="//input[@id='Y_addMemberComboSrc|input']"
    txtbox_dim3SrcInput_xpath="//input[@id='Z_addMemberComboSrc|input']"
    txtbox_dim4SrcInput_xpath="//input[@id='W_addMemberComboSrc|input']"
    txtbox_dim1DestInput_xpath="//input[@id='X_addMemberComboDest|input']"
    txtbox_dim2DestInput_xpath="//input[@id='Y_addMemberComboDest|input']"
    txtbox_dim3DestInput_xpath="//input[@id='Z_addMemberComboDest|input']"
    txtbox_dim4DestInput_xpath="//input[@id='W_addMemberComboDest|input']"
    link_driverTab_xpath="//a[@title='Define the Driver Basis for the rule.']"
    link_offsetTab_xpath="//a[@title='Define the Offset for the rule.']"
    radio_specifyDrvLoc_xpath="//input[@id='specifyDriverLoc|rb']"
    radio_allocEvenly_xpath="//input[@id='allocateEvenly|rb']"
    radio_offsetToSrcLoc_xpath="//input[@aria-label='Post Offset to the Source Location']"
    radio_offsetToAltLoc_xpath="//input[@aria-label='Post Offset to Alternate Location']"
    link_expandRuleSet_xpath="//span[contains(text(),'Ruleset 3')]/parent::span/parent::span/parent::div/span/a[@title='Expand']"
    label_createdAllocRule="//span[contains(text(),'allocRule1')]"
    label_createdAllocRule1="//span[contains(text(),'allocRule2')]"
    label_copiedAllocRule="(//span[contains(text(),'allocRule3')])[1]"
    label_copiedCustomRule="(//span[contains(text(),'customRule2')])[1]"
    label_createdCustomRule="(//span[contains(text(),'customRule1')])[1]"
    label_editAllocRuleHdng_xpath="//span[contains(text(),'Edit Allocation Rule')]|//span[contains(text(),'Edit Custom Rule')]"
    link_searchIconDim1Src_xpath="(//a[@title='Invoke Member Selector'])[1]"
    link_searchIconDim1Dest_xpath="(//a[@title='Invoke Member Selector'])[2]"
    label_duplicateRuleError_xpath="//span[contains(@title,'Duplicate Rule name. Calculation Program Rule name')]"
    label_formulaValidTxt_xpath="//span[contains(text(),'The rule and formula is valid')]"
    button_formulaValidPopUpOk_xpath="//span[contains(text(),'OK')]/parent::div/parent::button"
    link_dim1Trgt_xpath="(//a[contains(@id,'add')])[1]"
    link_dim2Trgt_xpath="(//a[contains(@id,'add')])[2]"
    txtbox_dim1Trgt_xpath="//input[@id='XaddMemberComboTrgt|input']"
    txtbox_dim2Trgt_xpath="//input[@id='YaddMemberComboTrgt|input']"
    link_dim2TrgtSearchIcon_xpath="//a[@id='searchTrgtBtnY']"
    
    
    
    
    def __init__(self,driver):
        self.driver = driver
    
    def createRSC(self,driver,rscName,rscDesc,RSC,searchIconYN,rscDimMem,testCaseName):
        DesignerPage.logger.info("******** Rule Set Creation is started **************")
        cc=commonComponents(driver)
        DesignerPage.logger.info("******** Clicking on Create ICON **************")
        cc.wait(3)
        cc.randomClick(self.link_plusicon_xpath)
        cc.wait(5)
        cc.randomClick(self.item_ruleSet_xpath)
        cc.wait(15)
        cc.randomClick(self.text_createRuleSet_xpath)
        if (cc.checkElement(5, self.text_definitionHeading_xpath) and  cc.checkElement(5, self.text_dimensionHeading_xpath)):
            DesignerPage.logger.info("******** Definition Tab and Dimension Selections are displayed to the user **************")
        else:
            driver.save_screenshot(".\\PCMCS_Jet_DesignerCard\\ScreenShots\\" + testCaseName+".png")
            DesignerPage.logger.info("******** Definition Tab and Dimension Selections are not displayed to the user **************")
        cc.setTxtBoxField(self.txtbox_ruleSetField_xpath, rscName)
        cc.setTxtBoxField(self.txtbox_ruleSetDesc_xpath, rscDesc)
        cc.randomClick(self.checkbox_enableRuleSet_xpath)
        cc.wait(3)
        if(RSC=="No"):
            cc.randomClick(self.button_rscDimSaveClose_xpath)
            cc.wait(3)
            cc.randomClick(self.button_ruleSetInfoOk_xpath)
            DesignerPage.logger.info("******** clicked on ok button **************")
            cc.wait(3)
            if(cc.checkElement(2, self.text_createdRuleSet_xpath)):
                DesignerPage.logger.info("******** Rule Set is Created Successfully with out RSC and is displayed correctly**************")
                assert True
                driver.quit()
            else:
                driver.save_screenshot(".\\PCMCS_Jet_DesignerCard\\ScreenShots\\" + testCaseName+".png") 
                DesignerPage.logger.info("******** Rule Set is not Created Successfully with out RSC and is displayed correctly**************")
                driver.quit()
                assert False
                
        else:
            cc.wait(3)
            cc.randomClick(self.text_dimensionHeading_xpath)
            cc.wait(10)
            if(cc.checkElement(2, self.button_addRSCDimension_xpath)):
                DesignerPage.logger.info("******** RSC Add Dimension Button is displayed **************")
            else:
                driver.save_screenshot(".\\PCMCS_Jet_DesignerCard\\ScreenShots\\" + testCaseName+".png")
                DesignerPage.logger.info("******** RSC Add Dimension Button is not displayed **************")
                
            cc.randomClick(self.button_addRSCDimension_xpath)
            cc.wait(1)
            DesignerPage.logger.info("******** RSC Add Dimension Button is clicked to select the Dimension **************")
            cc.randomClick(self.link_rscDimSelection_xpath)
            DesignerPage.logger.info("******** RSC R Add Dimension is selected **************")
        
            if (searchIconYN==False):
                cc.setTxtField(self.link_rscDimMemSelection_xpath, self.txtbox_rscDimMemSelection_xpath, rscDimMem)
                cc.typeEnter(2, self.txtbox_rscDimMemSelection_xpath, Keys.ENTER)
                DesignerPage.logger.info("******** RSC Add Dimension Member is selected **************")
                cc.randomClick(self.button_rscDimSaveClose_xpath)
                cc.wait(3)
                cc.randomClick(self.button_ruleSetInfoOk_xpath)
                DesignerPage.logger.info("******** clicked on ok button **************")
                cc.wait(3)
                if(cc.checkElement(2, self.text_createdRuleSet_xpath)):
                    DesignerPage.logger.info("******** Rule Set is Created Successfully and is displayed correctly**************")
                    driver.quit()
                    assert True
                else:
                    driver.save_screenshot(".\\PCMCS_Jet_DesignerCard\\ScreenShots\\" + testCaseName+".png")
                    DesignerPage.logger.info("******** Rule Set is not Created Successfully and is displayed correctly**************")
                    driver.quit()
                    assert False
            else:
                cc.wait(3)
                cc.randomClick(self.link_rscDimMemSelection_xpath)
                if(cc.checkElement(5, self.link_dimMemSearchIcon_xpath)):
                    DesignerPage.logger.info("******** User is displayed with search icon for member selector **************")
                    assert True
                else:
                    driver.save_screenshot(".\\PCMCS_Jet_DesignerCard\\ScreenShots\\" + testCaseName+".png") 
                    DesignerPage.logger.info("******** User is not displayed with search icon for member selector **************")
                    driver.quit()
                    assert False
                cc.randomClick(self.link_dimMemSearchIcon_xpath)
                cc.wait(10)
                cc.randomClick(self.label_memSelectorText_xpath)
                if(cc.checkElement(2, self.txtbox_dimMemInputSearch_xpath)):
                    DesignerPage.logger.info("******** User is displayed with text field to enter dimension member  **************")
                    assert True
                else:
                    driver.save_screenshot(".\\PCMCS_Jet_DesignerCard\\ScreenShots\\" + testCaseName+".png") 
                    DesignerPage.logger.info("******** User is not displayed with text field to enter dimension member  **************")
                    driver.quit()
                    assert False
                cc.setTxtBoxField(self.txtbox_dimMemInputSearch_xpath, rscDimMem)
                cc.randomClick(self.link_dimMemSelecorSearchIcon_xpath)
                cc.wait(4)
                cc.randomClick(self.link_reqDimMemSelection_xpath)
                cc.wait(2)
                DesignerPage.logger.info("******** User is clicking on Ok Button  **************")
                cc.randomClick(self.button_memSelectorOkButton_xpath)
                cc.wait(3)
                DesignerPage.logger.info("******** RSC Add Dimension Member is selected **************")
                cc.randomClick(self.button_rscDimSaveClose_xpath)
                cc.wait(3)
                cc.randomClick(self.button_ruleSetInfoOk_xpath)
                DesignerPage.logger.info("******** clicked on ok button **************")
                cc.wait(3)
                if(cc.checkElement(2, self.text_createdRuleSet1_xpath)):
                    DesignerPage.logger.info("******** Rule Set is Created Successfully and is displayed correctly**************")
                    driver.quit()
                    assert True
                else:
                    driver.save_screenshot(".\\PCMCS_Jet_DesignerCard\\ScreenShots\\" + testCaseName+".png") 
                    DesignerPage.logger.info("******** Rule Set is not Created Successfully and is displayed correctly**************")
                    driver.quit()
                    assert False

    def allocRuleValidations(self,driver,ruleName,ruleDescription,testCaseName):
        DesignerPage.logger.info("******** User is verifying mandatory selections for enabling a alloc rule **************")
        cc=commonComponents(driver)
        DesignerPage.logger.info("******** User is clicking on existing rule set to create new alloc rule **************")
        cc.wait(4)
        cc.randomClick(self.label_existingRuleSet3_xpath)
        cc.wait(5)
        cc.randomClick(self.link_plusicon_xpath)
        DesignerPage.logger.info("******** User has clicked on plus icon to select allocation rule **************")
        cc.wait(3)
        cc.randomClick(self.item_allocRule_xpath)
        cc.wait(14)
        if(cc.checkElement(2, self.label_createAllocRuleHdng_xpath)):
            DesignerPage.logger.info("******** User is displayed with Create Allocation Rule heading **************")
            assert True
        else:
            driver.save_screenshot(".\\PCMCS_Jet_DesignerCard\\ScreenShots\\" + testCaseName+".png") 
            DesignerPage.logger.info("******** User is not displayed with Create Allocation Rule heading **************")
            driver.quit()
            assert False
        DesignerPage.logger.info("******** User is entering rule name, description and enabling the rule **************")
        cc.wait(8)
        cc.setTxtBoxField(self.txtbox_allocRuleField_xpath, ruleName)
        cc.setTxtBoxField(self.txtbox_allocRuleDesc_xpath, ruleDescription)
        cc.wait(2)
        cc.randomClick(self.checkbox_enableRule_xpath)
        cc.wait(2)
        cc.randomClick(self.link_srcdestTab_xpath)
        cc.wait(5)
        if(cc.checkElement(5, self.link_dim1Rule_xpath) and cc.checkElement(2, self.link_dim2Rule_xpath)):
            DesignerPage.logger.info("******** user is displayed with all the available dimensions for selection **************")
            assert True
        else:
            driver.save_screenshot(".\\PCMCS_Jet_DesignerCard\\ScreenShots\\" + testCaseName+".png")
            DesignerPage.logger.info("******** user is displayed with all the available dimensions for selection **************")
            driver.quit()
            assert False
        DesignerPage.logger.info("*******with out providing mandatory selections user is trying to save the rule by enabling it")
        cc.wait(2)
        cc.randomClick(self.button_rscDimSaveClose_xpath)
        cc.wait(7)
        if(cc.checkElement(5, self.txt_errMsgValidationAlloc_xpath) and cc.checkElement(2, self.txt_errormsg1Alloc_xpath) and cc.checkElement(2, self.txt_errormsg2Alloc_xpath) and cc.checkElement(2, self.txt_errormsg3Alloc_xpath) and cc.checkElement(2, self.txt_errormsg4Alloc_xpath)):
            DesignerPage.logger.info("******** user is displayed with validation error messages **************")
            driver.quit()
            assert True
        else:
            driver.save_screenshot(".\\PCMCS_Jet_DesignerCard\\ScreenShots\\" + testCaseName+".png")
            DesignerPage.logger.info("******** user is not displayed with validations messages **************")
            driver.quit()
            assert False

    
    def customRuleValidations(self,driver,ruleName,ruleDescription,formula,testCaseName):
        DesignerPage.logger.info("******** User is verifying mandatory selections for enabling a custom rule **************")
        cc=commonComponents(driver)
        DesignerPage.logger.info("******** User is clicking on existing rule set to create new alloc rule **************")
        cc.wait(4)
        cc.randomClick(self.label_existingRuleSet3_xpath)
        cc.wait(5)
        cc.randomClick(self.link_plusicon_xpath)
        DesignerPage.logger.info("******** User has clicked on plus icon to select allocation rule **************")
        cc.wait(3)
        cc.randomClick(self.item_customRule_xpath)
        cc.wait(14)
        if(cc.checkElement(2, self.label_createCustomRuleHdng_xpath)):
            DesignerPage.logger.info("******** User is displayed with Create Custom Rule heading **************")
            assert True
        else:
            driver.save_screenshot(".\\PCMCS_Jet_DesignerCard\\ScreenShots\\" + testCaseName+".png") 
            DesignerPage.logger.info("******** User is not displayed with Create Custom Rule heading **************")
            driver.quit()
            assert False
        DesignerPage.logger.info("******** User is entering rule name, description and enabling the rule **************")
        cc.wait(3)
        cc.setTxtBoxField(self.txtbox_allocRuleField_xpath, ruleName)
        cc.setTxtBoxField(self.txtbox_allocRuleDesc_xpath, ruleDescription)
        cc.wait(2)
        cc.randomClick(self.checkbox_enableRule_xpath)
        DesignerPage.logger.info("******** User is clicking on target tab **************")
        cc.randomClick(self.link_trgtTab_xpath)
        cc.wait(5)
        cc.randomClick(self.button_rscDimSaveClose_xpath)
        cc.wait(7)
        if(cc.checkElement(5, self.txt_errMsgValidationFormula_xpath)):
            DesignerPage.logger.info("******** user is displayed with formula required validation error messages **************")
            assert True
        else:
            driver.save_screenshot(".\\PCMCS_Jet_DesignerCard\\ScreenShots\\" + testCaseName+".png")
            DesignerPage.logger.info("******** user is not displayed with formula required validation messages **************")
            driver.quit()
            assert False   
        cc.wait(2)
        cc.randomClick(self.button_formulaValidPopUpOk_xpath)
        cc.wait(3)
        DesignerPage.logger.info("******** User is entering valid formula **************")
        cc.setTxtBoxField(self.txtbox_formulaTextBx_xpath, formula)
        cc.wait(3)
        cc.randomClick(self.button_rscDimSaveClose_xpath)
        cc.wait(7)
        if(cc.checkElement(5, self.txt_errMsg1Custom_xpath) and cc.checkElement(5, self.txt_errMsg2Custom_xpath)):
            DesignerPage.logger.info("******** user is displayed with validation error messages when dim members are not selected**************")
            driver.quit()
            assert True
        else:
            driver.save_screenshot(".\\PCMCS_Jet_DesignerCard\\ScreenShots\\" + testCaseName+".png")
            DesignerPage.logger.info("******** user is not displayed with validation error messages when dim members are not selected **************")
            driver.quit()
            assert False  
                     
         
    def creatAllocRule(self,driver,ruleName,ruleDescription,searchIconYN,dim1Src,dim2Src,dim1Dest,dim2Dest,testCaseName):
        DesignerPage.logger.info("******** User is creating Allocation Rule **************")
        cc=commonComponents(driver)
        DesignerPage.logger.info("******** User is clicking on existing rule set to create new alloc rule **************")
        cc.wait(10)
        cc.randomClick(self.label_existingRuleSet3_xpath)
        cc.wait(5)
        cc.randomClick(self.link_plusicon_xpath)
        DesignerPage.logger.info("******** User has clicked on plus icon to select allocation rule **************")
        cc.wait(3)
        cc.randomClick(self.item_allocRule_xpath)
        cc.wait(14)
        if(cc.checkElement(2, self.label_createAllocRuleHdng_xpath)):
            DesignerPage.logger.info("******** User is displayed with Create Allocation Rule heading **************")
            assert True
        else:
            driver.save_screenshot(".\\PCMCS_Jet_DesignerCard\\ScreenShots\\" + testCaseName+".png") 
            DesignerPage.logger.info("******** User is not displayed with Create Allocation Rule heading **************")
            driver.quit()
            assert False
        DesignerPage.logger.info("******** User is entering rule name, description and enabling the rule **************")
        cc.wait(3)
        cc.setTxtBoxField(self.txtbox_allocRuleField_xpath, ruleName)
        cc.setTxtBoxField(self.txtbox_allocRuleDesc_xpath, ruleDescription)
        cc.wait(2)
        cc.randomClick(self.checkbox_enableRule_xpath)
        cc.randomClick(self.dropDown_allocatedAmount_xpath)
        cc.wait(2)
        default_AllocatedTypeAmount='None'
        actual_AllocatedTypeAmount=cc.getText(self.txt_defaultAllocatedAmount_xpath)
        if(actual_AllocatedTypeAmount==default_AllocatedTypeAmount):
            DesignerPage.logger.info("********Default value for allocated amount is: " + actual_AllocatedTypeAmount)
            assert True
        else:
            DesignerPage.logger.info("********Default value for allocated amount is: " + actual_AllocatedTypeAmount)
            driver.quit()
            assert False
        cc.randomClick(self.label_amountField_xpath)
        cc.wait(5)
        amountTxtBoxStatus=bool(cc.checkEnabled(self.txtbox_amountField_xpath))
        DesignerPage.logger.info(amountTxtBoxStatus)
        if(amountTxtBoxStatus):
            driver.save_screenshot(".\\PCMCS_Jet_DesignerCard\\ScreenShots\\" + testCaseName+".png")
            DesignerPage.logger.info("******** amount text box is not disabled for user **************")
            driver.quit()
            assert False
            
        else:
            DesignerPage.logger.info("******** amount text box is disabled for user **************")
            assert True
        cc.randomClick(self.link_srcdestTab_xpath)
        cc.wait(5)
        if(cc.checkElement(5, self.link_dim1Rule_xpath) and cc.checkElement(2, self.link_dim2Rule_xpath)):
            DesignerPage.logger.info("******** user is displayed with all the available dimensions for selection **************")
            assert True
        else:
            driver.save_screenshot(".\\PCMCS_Jet_DesignerCard\\ScreenShots\\" + testCaseName+".png")
            DesignerPage.logger.info("******** user is displayed with all the available dimensions for selection **************")
            driver.quit()
            assert False
        if(searchIconYN==False):
            DesignerPage.logger.info("******** all members are selected through text fields **************")

            cc.randomClick(self.link_dim1Rule_xpath)
            cc.wait(2)
            cc.setTxtField(self.link_dim1SrcLink_xpath, self.txtbox_dim1SrcInput_xpath, dim1Src)
            cc.typeEnter(1, self.txtbox_dim1SrcInput_xpath, Keys.ENTER)
            DesignerPage.logger.info("******** user entered dim1 source member **************")
            cc.wait(3)
            cc.randomClick(self.link_dim2Rule_xpath)
            cc.wait(2)
            cc.setTxtField(self.link_dim2SrcLink_xpath, self.txtbox_dim2SrcInput_xpath, dim2Src)
            cc.typeEnter(1, self.txtbox_dim2SrcInput_xpath, Keys.ENTER)
            DesignerPage.logger.info("******** user entered dim2 source member**************")
            cc.wait(3)
            cc.setTxtField(self.link_dim1DestLink_xpath, self.txtbox_dim1DestInput_xpath, dim1Dest)
            cc.typeEnter(1, self.txtbox_dim1DestInput_xpath, Keys.ENTER)
            DesignerPage.logger.info("******** user entered dim1 destination member**************")
            cc.wait(3)
            cc.setTxtField(self.link_dim2DestLink_xpath, self.txtbox_dim2DestInput_xpath, dim2Dest)
            cc.typeEnter(1, self.txtbox_dim2DestInput_xpath, Keys.ENTER)
            DesignerPage.logger.info("******** user entered dim2 destination member **************")
        else:
            DesignerPage.logger.info("******** Dimension 1 Src and Dest are selected from member selector **************")
            cc.randomClick(self.link_dim1Rule_xpath)
            cc.wait(1)
            cc.randomClick(self.link_dim1SrcLink_xpath)
            cc.wait(3)
            if(cc.checkElement(3, self.link_searchIconDim1Src_xpath)):
                DesignerPage.logger.info("******** User is displayed with search icon for member selector **************")
                assert True
            else:
                driver.save_screenshot(".\\PCMCS_Jet_DesignerCard\\ScreenShots\\" + testCaseName+".png") 
                DesignerPage.logger.info("******** User is not displayed with search icon for member selector **************")
                driver.quit()
                assert False
            cc.randomClick(self.link_searchIconDim1Src_xpath)
            cc.wait(5)
            cc.randomClick(self.label_memSelectorText_xpath)
            if(cc.checkElement(2, self.txtbox_dimMemInputSearch_xpath)):
                DesignerPage.logger.info("******** User is displayed with text field to enter dimension member  **************")
                assert True
            else:
                driver.save_screenshot(".\\PCMCS_Jet_DesignerCard\\ScreenShots\\" + testCaseName+".png") 
                DesignerPage.logger.info("******** User is not displayed with text field to enter dimension member  **************")
                driver.quit()
                assert False
            cc.setTxtBoxField(self.txtbox_dimMemInputSearch_xpath, dim1Src)
            cc.randomClick(self.link_dimMemSelecorSearchIcon_xpath)
            cc.wait(4)
            cc.randomClick(self.link_reqDim1SrcSelection_xpath)
            cc.wait(3)
            DesignerPage.logger.info("******** User is clicking on Ok Button  **************")
            cc.randomClick(self.button_memSelectorRuleOkBtn_xpath)  
            cc.wait(3)
            DesignerPage.logger.info("******** Rule - Src1 Add Dimension Member is selected **************")
            cc.wait(3)
            cc.randomClick(self.link_dim1DestLink_xpath)
            cc.wait(3)
            if(cc.checkElement(3, self.link_searchIconDim1Dest_xpath)):
                DesignerPage.logger.info("******** User is displayed with search icon for member selector **************")
                assert True
            else:
                driver.save_screenshot(".\\PCMCS_Jet_DesignerCard\\ScreenShots\\" + testCaseName+".png") 
                DesignerPage.logger.info("******** User is not displayed with search icon for member selector **************")
                driver.quit()
                assert False
            cc.randomClick(self.link_searchIconDim1Dest_xpath)
            cc.wait(5)
            cc.randomClick(self.label_memSelectorText_xpath)
            if(cc.checkElement(2, self.txtbox_dimMemInputSearch_xpath)):
                DesignerPage.logger.info("******** User is displayed with text field to enter dimension member  **************")
                assert True
            else:
                driver.save_screenshot(".\\PCMCS_Jet_DesignerCard\\ScreenShots\\" + testCaseName+".png") 
                DesignerPage.logger.info("******** User is not displayed with text field to enter dimension member  **************")
                driver.quit()
                assert False
            cc.setTxtBoxField(self.txtbox_dimMemInputSearch_xpath, dim1Dest)
            cc.randomClick(self.link_dimMemSelecorSearchIcon_xpath)
            cc.wait(4)
            cc.randomClick(self.link_reqDim1DestSelection_xpath)
            cc.wait(3)
            DesignerPage.logger.info("******** User is clicking on Ok Button  **************")
            cc.randomClick(self.button_memSelectorRuleOkBtn_xpath)
            cc.wait(3)
            DesignerPage.logger.info("******** Rule - Dest1 Add Dimension Member is selected **************")
            cc.wait(3)   
            cc.randomClick(self.link_dim2Rule_xpath)
            cc.setTxtField(self.link_dim2SrcLink_xpath, self.txtbox_dim2SrcInput_xpath, dim2Src)
            cc.typeEnter(1, self.txtbox_dim2SrcInput_xpath, Keys.ENTER)
            DesignerPage.logger.info("******** user entered dim2 source member**************")
            cc.wait(3)
            cc.setTxtField(self.link_dim2DestLink_xpath, self.txtbox_dim2DestInput_xpath, dim2Dest)
            cc.typeEnter(1, self.txtbox_dim2DestInput_xpath, Keys.ENTER)
            DesignerPage.logger.info("******** user entered dim2 destination member **************") 
        cc.wait(3)                       
        DesignerPage.logger.info("******** user is clicking on driver tab **************")
        cc.randomClick(self.link_driverTab_xpath)
        cc.wait(5)
        defSelectedStatus= cc.isSelected(self.radio_specifyDrvLoc_xpath)
        DesignerPage.logger.info(defSelectedStatus)
        if(defSelectedStatus==True):
            DesignerPage.logger.info("*******By default specify driver location option is selected")
            assert True
        else:
            driver.save_screenshot(".\\PCMCS_Jet_DesignerCard\\ScreenShots\\" + testCaseName+".png")
            DesignerPage.logger.info("*****By default specify driver location is not selected ")
            driver.quit()
            assert False
        DesignerPage.logger.info("******** user is clicking on offset tab **************")
        cc.randomClick(self.link_offsetTab_xpath)
        cc.wait(3)
        defSelectedStatus1=cc.isSelected(self.radio_offsetToSrcLoc_xpath)
        DesignerPage.logger.info(defSelectedStatus1)
        if(defSelectedStatus==True):
            DesignerPage.logger.info("*******By default post offset to src loc is selected")
            assert True
        else:
            driver.save_screenshot(".\\PCMCS_Jet_DesignerCard\\ScreenShots\\" + testCaseName+".png")
            DesignerPage.logger.info("*****By default post offset to src loc is not selected ")
            driver.quit()
            assert False
        DesignerPage.logger.info("*******User is clicking on save and close button")
        cc.wait(2)
        cc.randomClick(self.button_rscDimSaveClose_xpath)
        cc.wait(2)
        cc.randomClick(self.button_ruleSetInfoOk_xpath)
        cc.wait(4)
        cc.randomClick(self.label_existingRuleSet3_xpath)
        cc.wait(4)
        cc.randomClick(self.link_expandRuleSet_xpath)
        cc.wait(2)
        #Here this line of code is used to differentiate the allocation rule creation in two ways
        if(searchIconYN==False):
            if(cc.checkElement(2, self.label_createdAllocRule)):
                cc.randomClick(self.label_createdAllocRule)
                DesignerPage.logger.info("*******Created alloc rule saved successfully")
                driver.quit()
                assert True
            else:
                driver.save_screenshot(".\\PCMCS_Jet_DesignerCard\\ScreenShots\\" + testCaseName+".png")
                DesignerPage.logger.info("*****Created alloc rule is not saved successfully ")
                driver.quit()
                assert False
        ## here else part selects the alloc rule that is created through member selector
        else:
            if(cc.checkElement(2, self.label_createdAllocRule1)):
                cc.randomClick(self.label_createdAllocRule1)
                DesignerPage.logger.info("*******Created alloc rule saved successfully")
                driver.quit()
                assert True
            else:
                driver.save_screenshot(".\\PCMCS_Jet_DesignerCard\\ScreenShots\\" + testCaseName+".png")
                DesignerPage.logger.info("*****Created alloc rule is not saved successfully ")
                driver.quit()
                assert False
    

        
    
    def createCustomRule(self,driver,ruleName,ruleDescription,formula,dim1Trgt,dim2Trgt,formulaValidation,formula1,formula2,testCaseName):
        DesignerPage.logger.info("******** User is creating custom calculation Rule **************")
        cc=commonComponents(driver)
        DesignerPage.logger.info("******** User is clicking on existing rule set to create new custom calc rule **************")
        cc.wait(4)
        cc.randomClick(self.label_existingRuleSet3_xpath)
        cc.wait(5)
        cc.randomClick(self.link_plusicon_xpath)
        DesignerPage.logger.info("******** User has clicked on plus icon to select custom rule **************")
        cc.wait(3)
        cc.randomClick(self.item_customRule_xpath)
        cc.wait(14)
        if(cc.checkElement(5, self.label_createCustomRuleHdng_xpath)):
            DesignerPage.logger.info("******** User is displayed with Create Custom Rule heading **************")
            assert True
        else:
            driver.save_screenshot(".\\PCMCS_Jet_DesignerCard\\ScreenShots\\" + testCaseName+".png") 
            DesignerPage.logger.info("******** User is not displayed with Create Custom Rule heading **************")
            driver.quit()
            assert False
        DesignerPage.logger.info("******** User is entering rule name, description and enabling the rule **************")
        cc.wait(8)
        cc.setTxtBoxField(self.txtbox_allocRuleField_xpath, ruleName)
        cc.setTxtBoxField(self.txtbox_allocRuleDesc_xpath, ruleDescription)
        cc.wait(5)
        cc.randomClick(self.checkbox_enableRule_xpath)
        DesignerPage.logger.info("******** User is clicking on target tab **************")
        cc.wait(5)
        cc.randomClick(self.link_trgtTab_xpath)
        cc.wait(5)
        if(cc.checkElement(5, self.link_dim1RuleCC_xpath) and cc.checkElement(5, self.link_dim2RuleCC_xpath)):
            DesignerPage.logger.info("******** user is displayed with all the available dimensions for selection **************")
            assert True
        else:
            driver.save_screenshot(".\\PCMCS_Jet_DesignerCard\\ScreenShots\\" + testCaseName+".png")
            DesignerPage.logger.info("******** user is displayed with all the available dimensions for selection **************")
            driver.quit()
            assert False
        cc.wait(4)
        DesignerPage.logger.info("******** user is entering dim1 target member************")
        cc.randomClick(self.link_dim1RuleCC_xpath)
        cc.wait(3)
        cc.randomClick(self.link_dim1Trgt_xpath)
        cc.wait(3)
        cc.setTxtBoxField(self.txtbox_dim1Trgt_xpath, dim1Trgt)
        cc.typeEnter(1, self.txtbox_dim1Trgt_xpath, Keys.ENTER)
        cc.wait(2)
        DesignerPage.logger.info("******** user is entering dim2 target member************")
        cc.randomClick(self.link_dim2RuleCC_xpath)
        cc.wait(3)
        cc.randomClick(self.link_dim2Trgt_xpath)
        cc.wait(3)
        cc.randomClick(self.link_dim2TrgtSearchIcon_xpath)
        cc.wait(5)
        cc.randomClick(self.label_memSelectorText_xpath)
        if(cc.checkElement(3, self.txtbox_dimMemInputSearch_xpath)):
            DesignerPage.logger.info("******** User is displayed with text field to enter dimension member  **************")
            assert True
        else:
            driver.save_screenshot(".\\PCMCS_Jet_DesignerCard\\ScreenShots\\" + testCaseName+".png") 
            DesignerPage.logger.info("******** User is not displayed with text field to enter dimension member  **************")
            driver.quit()
            assert False
        cc.setTxtBoxField(self.txtbox_dimMemInputSearch_xpath, dim2Trgt)
        cc.randomClick(self.link_dimMemSelecorSearchIcon_xpath)
        cc.wait(4)
        cc.randomClick(self.link_reqTrgtDimMemSelection_xpath)
        cc.wait(3)
        DesignerPage.logger.info("******** User is clicking on Ok Button  **************")
        cc.randomClick(self.button_memSelectorRuleOkBtn_xpath)  
        cc.wait(3)
        
        if(formulaValidation=='NO'):
            DesignerPage.logger.info("******** User is entering valid formula **************")
            cc.setTxtBoxField(self.txtbox_formulaTextBx_xpath, formula)
            cc.wait(4)
            cc.randomClick(self.button_validateFormula_xpath)
            cc.wait(2)
            if(cc.checkElement(5, self.label_formulaValidTxt_xpath)):
                DesignerPage.logger.info("******** user is displayed with rule and formula valid message************")
                assert True
            else:
                driver.save_screenshot(".\\PCMCS_Jet_DesignerCard\\ScreenShots\\" + testCaseName+".png") 
                DesignerPage.logger.info("******** user is not displayed with rule and formula valid message************")
                driver.quit()
                assert False
            cc.wait(4)
            cc.randomClick(self.button_formulaValidPopUpOk_xpath)
            cc.wait(2)
            DesignerPage.logger.info("*******User is clicking on save and close button")
            cc.wait(5)
            cc.randomClick(self.button_rscDimSaveClose_xpath)
            cc.wait(2)
            cc.randomClick(self.button_ruleSetInfoOk_xpath)
            DesignerPage.logger.info("*******User saved the rule and confirming the rule saving process")
            cc.wait(4)
            cc.randomClick(self.label_existingRuleSet3_xpath)
            cc.wait(4)
            cc.randomClick(self.link_expandRuleSet_xpath)
            cc.wait(2)
            if(cc.checkElement(5, self.label_createdCustomRule)):
                cc.randomClick(self.label_createdCustomRule)
                DesignerPage.logger.info("*******Created custom rule saved successfully")
                driver.quit()
                assert True
            else:
                driver.save_screenshot(".\\PCMCS_Jet_DesignerCard\\ScreenShots\\" + testCaseName+".png")
                DesignerPage.logger.info("*****Created custom rule is not saved successfully ")
                driver.quit()
                assert False
        else:
            DesignerPage.logger.info("******** User is entering invalid formula1 **************")
            cc.setTxtBoxField(self.txtbox_formulaTextBx_xpath, formula)
            cc.wait(4)
            cc.randomClick(self.button_validateFormula_xpath)
            cc.wait(2)
            formulaValidation1="Warning:  Rule cannot be enabled because it has failed Validations.  The validation failures are as follows: The argument [Script] is missing one or more dimensions"
            if(cc.getText(self.txt_errDuplicateFilers_xpath)==formulaValidation1):
                DesignerPage.logger.info("******** user is displayed with warning message************")
                assert True
            else:
                driver.save_screenshot(".\\PCMCS_Jet_DesignerCard\\ScreenShots\\" + testCaseName+".png") 
                DesignerPage.logger.info("******** user is not displayed with rule and formula valid message************")
                driver.quit()
                assert False
            cc.wait(4)
            cc.randomClick(self.button_formulaValidPopUpOk_xpath)
            cc.wait(5)
            DesignerPage.logger.info("******** User is entering invalid formula2 **************")
            cc.setTxtBoxField(self.txtbox_formulaTextBx_xpath, formula1)
            cc.wait(4)
            cc.randomClick(self.button_validateFormula_xpath)
            cc.wait(2)
            formulaValidation2="Warning:  Rule cannot be enabled because it has failed Validations.  The validation failures are as follows: Invalid formula, the rhs not found in the formula"
            if(cc.getText(self.txt_errDuplicateFilers_xpath)==formulaValidation2):
                DesignerPage.logger.info("******** user is displayed with warning message************")
                assert True
            else:
                driver.save_screenshot(".\\PCMCS_Jet_DesignerCard\\ScreenShots\\" + testCaseName+".png") 
                DesignerPage.logger.info("******** user is not displayed with rule and formula valid message************")
                driver.quit()
                assert False
            cc.wait(4)
            cc.randomClick(self.button_formulaValidPopUpOk_xpath)
            cc.wait(5)            
            DesignerPage.logger.info("******** User is entering invalid formula3 **************")
            cc.setTxtBoxField(self.txtbox_formulaTextBx_xpath, formula2)
            cc.wait(4)
            cc.randomClick(self.button_validateFormula_xpath)
            cc.wait(2)
            formulaValidation3="Warning:  Rule cannot be enabled because it has failed Validations.  The validation failures are as follows: Duplicate dimensions in a tuple in function [TUPLE CONSTRUCTOR] on line [1]"
            if(cc.getText(self.txt_errDuplicateFilers_xpath)==formulaValidation3):
                DesignerPage.logger.info("******** user is displayed with warning message************")
                assert True
                driver.quit()
            else:
                driver.save_screenshot(".\\PCMCS_Jet_DesignerCard\\ScreenShots\\" + testCaseName+".png") 
                DesignerPage.logger.info("******** user is not displayed with rule and formula valid message************")
                driver.quit()
                assert False
  
       
    
    def addFiltersRule(self,driver,AllocRule,dimMbr,testCaseName):
        DesignerPage.logger.info("******** User is adding filters to customer rule dim members**************")
        cc=commonComponents(driver)
        cc.randomClick(self.label_existingRuleSet3_xpath)
        cc.wait(4)
        cc.randomClick(self.link_expandRuleSet_xpath)
        cc.wait(4)
        if (AllocRule==True):
            DesignerPage.logger.info("******** User is clicking on allocation rule to edit **************")
            cc.randomClick(self.label_copiedAllocRule)
        else:
            DesignerPage.logger.info("******** User is clicking on custom rule to edit **************")
            cc.randomClick(self.label_copiedCustomRule)
        cc.wait(3)
        cc.randomClick(self.link_editButton_xpath)
        cc.wait(8)
        if(cc.checkElement(5, self.label_editAllocRuleHdng_xpath)):
            DesignerPage.logger.info("******** User is displayed with edit rule page **************")
            assert True
        else:
            driver.save_screenshot(".\\PCMCS_Jet_DesignerCard\\ScreenShots\\" + testCaseName+".png")
            DesignerPage.logger.info("******** User is not displayed with edit rule page **************")
            driver.quit()
            assert False
        if(AllocRule==True):
            DesignerPage.logger.info("******** User is clicking on SRC/Dest Tab of the selected Alloc rule **************")
            cc.wait(5)
            cc.randomClick(self.link_srcdestTab_xpath)
            cc.wait(8)
            cc.randomClick(self.link_dim1Rule_xpath)
            cc.wait(4)
            cc.randomClick(self.link_dim1SrcAddedLink_xpath)
            cc.wait(4)
            if(cc.checkElement(2, self.link_manageFilters_xpath)):
                DesignerPage.logger.info("******** User is displayed with manage filters option **************")
                assert True
            else:
                driver.save_screenshot(".\\PCMCS_Jet_DesignerCard\\ScreenShots\\" + testCaseName+".png")  
                DesignerPage.logger.info("******** User is not displayed with manage filters option **************")
                assert False            
            cc.randomClick(self.link_manageFilters_xpath)
            cc.wait(3)            
        else:
            DesignerPage.logger.info("******** User is clicking on target tab of the selected custom rule **************")
            cc.randomClick(self.link_trgtTab_xpath)
            cc.wait(10)
            cc.randomClick(self.link_dim1RuleCC_xpath)
            cc.wait(3)   
            cc.randomClick(self.link_addDim1MemTrgt_xpath)     
            cc.wait(3)
            if(cc.checkElement(2, self.link_manageFilters_xpath)):
                DesignerPage.logger.info("******** User is displayed with manage filters option **************")
                assert True
            else:
                driver.save_screenshot(".\\PCMCS_Jet_DesignerCard\\ScreenShots\\" + testCaseName+".png")  
                DesignerPage.logger.info("******** User is not displayed with manage filters option **************")
                assert False
            cc.randomClick(self.link_manageFilters_xpath)
            cc.wait(3)
        if(cc.checkElement(3, self.txt_mngFilterHdng_xpath)):
            DesignerPage.logger.info("******** User is displayed with manage filters hdng on pop up window **************")
            assert True
        else:
            driver.save_screenshot(".\\PCMCS_Jet_DesignerCard\\ScreenShots\\" + testCaseName+".png")      
            DesignerPage.logger.info("******** User is not displayed with manage filters hdng on pop up window **************")
            assert False
        cc.randomClick(self.txt_mngFilterHdng_xpath)
        if(cc.checkElement(2, self.button_addFilters_xpath)):
            DesignerPage.logger.info("******** User is displayed with add filter plus icon **************")
            assert True
        else:
            driver.save_screenshot(".\\PCMCS_Jet_DesignerCard\\ScreenShots\\" + testCaseName+".png")      
            DesignerPage.logger.info("******** User is not displayed with add filters plus icon **************")
            assert False
        cc.wait(5)
        cc.randomClick(self.button_addFilters_xpath)
        cc.wait(3)
        DesignerPage.logger.info("******** User entering the dimension member **************")
        cc.setTxtBoxField(self.txtbox_dimFilter_xpath, dimMbr)
        cc.typeEnter(2, self.txtbox_dimFilter_xpath, Keys.ENTER)
        cc.wait(2)
        cc.randomClick(self.button_addFilters_xpath)
        cc.wait(2)
        DesignerPage.logger.info("******** User is trying to enter duplicate filter  **************")
        cc.setTxtBoxField(self.txtbox_dimFilter1_xpath, dimMbr)
        cc.typeEnter(2, self.txtbox_dimFilter1_xpath, Keys.ENTER)        
        DesignerPage.logger.info("******** User is clicking on OK button **************")    
        cc.wait(3)    
        cc.randomClick(self.button_saveFiltersOk_xpath)
        cc.wait(3)
        errortext="Duplicate filters are not allowed."
        if(cc.getText(self.txt_errDuplicateFilers_xpath)==errortext):
            DesignerPage.logger.info("******** User is displayed with duplicate filtes error: " + cc.getText(self.txt_errDuplicateFilers_xpath))  
            assert True
        else:
            driver.save_screenshot(".\\PCMCS_Jet_DesignerCard\\ScreenShots\\" + testCaseName+".png") 
            DesignerPage.logger.info("******** User is not displayed with duplicate filtes error **************" + cc.getText(self.txt_errDuplicateFilers_xpath))  
            assert False
        cc.wait(3)
        cc.randomClick(self.button_dupErrFilterOk_xpath)
        cc.wait(3)
        DesignerPage.logger.info("******** User is deleting the duplicate filter added **************")  
        cc.randomClick(self.button_dupFilterRemove_xpath)
        cc.wait(2)
        cc.randomClick(self.button_saveFiltersOk_xpath)
        cc.wait(5)
        if(cc.checkElement(3, self.link_addedFilterDim1Trgt_xpath)):
            DesignerPage.logger.info("******** User is displayed with added filter for dim1 trgt **************")  
            assert True
        else:
            driver.save_screenshot(".\\PCMCS_Jet_DesignerCard\\ScreenShots\\" + testCaseName+".png")      
            DesignerPage.logger.info("******** User is not displayed with added filter for dim1 trgt **************")  
            assert False
        cc.randomClick(self.button_rscDimSaveClose_xpath)
        cc.wait(3)
        cc.randomClick(self.button_ruleSetInfoOk_xpath)   
        cc.wait(5)
        cc.randomClick(self.label_existingRuleSet3_xpath)    
        cc.wait(5)
        if(AllocRule==True):
            DesignerPage.logger.info("******** User has saved the alloc rule with filters for dim1  **************")    
            cc.randomClick(self.label_copiedAllocRule)
        else:
            cc.randomClick(self.label_copiedCustomRule)
            DesignerPage.logger.info("******** User has saved the custom rule with filters for dim1  **************")    
        driver.quit()
            
            
    def editRule(self,driver,AllocRule,testCaseName):
        DesignerPage.logger.info("******** User is editing the allocation rule **************")
        cc=commonComponents(driver)
        DesignerPage.logger.info("******** User is clicking on existing allocation rule set to disable the rule **************")
        cc.wait(5)
        cc.randomClick(self.label_existingRuleSet3_xpath)
        cc.wait(14)
        cc.randomClick(self.link_expandRuleSet_xpath)
        cc.wait(5)
        if (AllocRule==True):
            DesignerPage.logger.info("******** User is clicking on allocation rule to edit **************")
            cc.randomClick(self.label_createdAllocRule)
        else:
            DesignerPage.logger.info("******** User is clicking on custom rule to edit **************")
            cc.randomClick(self.label_createdCustomRule)
        cc.wait(3)
        cc.randomClick(self.link_editButton_xpath)
        cc.wait(8)
        if(cc.checkElement(5, self.label_editAllocRuleHdng_xpath)):
            DesignerPage.logger.info("******** User is displayed with edit rule page **************")
            assert True
        else:
            driver.save_screenshot(".\\PCMCS_Jet_DesignerCard\\ScreenShots\\" + testCaseName+".png")
            DesignerPage.logger.info("******** User is not displayed with edit rule page **************")
            driver.quit()
            assert False
        DesignerPage.logger.info("******** User is disabling the rule **************")
        cc.wait(4)
        cc.randomClick(self.checkbox_enableRule_xpath)
        DesignerPage.logger.info("******** User clicked on the enabled checkbox **************")
        cc.wait(2)
        cc.randomClick(self.button_rscDimSaveClose_xpath)
        cc.wait(3)
        cc.randomClick(self.button_ruleSetInfoOk_xpath)
        cc.wait(3)
        cc.randomClick(self.label_existingRuleSet3_xpath)
        cc.wait(4)
        #cc.randomClick(self.link_expandRuleSet_xpath)
        #cc.wait(2)
        if(AllocRule==True):
            if(cc.checkElement(2, self.label_createdAllocRule)):
                cc.randomClick(self.label_createdAllocRule)
                DesignerPage.logger.info("*******edited rule saved successfully")
                assert True
            else:
                driver.save_screenshot(".\\PCMCS_Jet_DesignerCard\\ScreenShots\\" + testCaseName+".png")
                DesignerPage.logger.info("*****edited rule is not saved successfully ")
                driver.quit()
                assert False
        else:
            if(cc.checkElement(2, self.label_createdCustomRule)):
                cc.randomClick(self.label_createdCustomRule)
                DesignerPage.logger.info("*******edited rule saved successfully")
                assert True
            else:
                driver.save_screenshot(".\\PCMCS_Jet_DesignerCard\\ScreenShots\\" + testCaseName+".png")
                DesignerPage.logger.info("*****edited rule is not saved successfully ")
                driver.quit()
                assert False            
        cc.wait(3)
        if(cc.checkElement(10, self.label_ruleEnbleStatus)):
            DesignerPage.logger.info("********Rule is disabled correctly**************")
            driver.quit()
            assert True
        
        else:
            driver.save_screenshot(".\\PCMCS_Jet_DesignerCard\\ScreenShots\\" + testCaseName+".png") 
            DesignerPage.logger.info("********Rule is not disabled**************")
            driver.quit()
            assert False
            
    def deleteRule(self,driver,AllocRule,testCaseName):
        DesignerPage.logger.info("******** User is deleting the rule **************")
        cc=commonComponents(driver)
        DesignerPage.logger.info("******** User is clicking on existing rule set to delete the selected rule **************")
        cc.wait(7)
        cc.randomClick(self.label_existingRuleSet3_xpath)
        cc.wait(6)
        cc.randomClick(self.link_expandRuleSet_xpath)
        cc.wait(6)
        DesignerPage.logger.info("******** User is clicking on required rule to delete **************")
        if(AllocRule==True):
            DesignerPage.logger.info("******** User is clicking on alloc rule to delete **************")
            cc.randomClick(self.label_createdAllocRule1)
        else:
            DesignerPage.logger.info("******** User is clicking on custom rule to delete **************")
            cc.randomClick(self.label_createdCustomRule)
        cc.wait(5)
        cc.randomClick(self.link_deleteButton_xpath)
        cc.wait(2)
        if(cc.checkElement(10, self.label_delteRuleTxt_xpath)):
            DesignerPage.logger.info("******** User is displayed with delete rule message  **************")
            assert True
        
        else:
            driver.save_screenshot(".\\PCMCS_Jet_DesignerCard\\ScreenShots\\" + testCaseName+".png")
            DesignerPage.logger.info("******** User is not displayed with delete rule message  **************")
            driver.quit()
            assert False
        cc.wait(5)
        DesignerPage.logger.info("******** User is clicking on ok button to delete rule set  **************")
        cc.randomClick(self.button_deleteRuleSetYes_xpath)
        driver.quit()

    def copyRule(self,driver,AllocRule,rul1Name,rul2Name,testCaseName):
        DesignerPage.logger.info("******** User is trying to copy rule **************")  
        cc=commonComponents(driver)
        cc.randomClick(self.label_existingRuleSet3_xpath)
        cc.wait(8)
        cc.randomClick(self.link_expandRuleSet_xpath)
        cc.wait(8)
        if(AllocRule==True):
            DesignerPage.logger.info("******** User is copying allocation rule **************") 
            cc.randomClick(self.label_createdAllocRule1)
        else:
            DesignerPage.logger.info("******** User is copying custom rule **************") 
            cc.randomClick(self.label_createdCustomRule)
        cc.wait(3)
        cc.randomClick(self.link_copyImage_xpath)
        cc.wait(3)
        if(cc.checkElement(2, self.label_copyRuleHdng_xpath)):
            DesignerPage.logger.info("******** User is displayed with copy rule window **************") 
            assert True
        else:
            driver.save_screenshot(".\\PCMCS_Jet_DesignerCard\\ScreenShots\\" + testCaseName+".png")   
            DesignerPage.logger.info("******** User is not displayed with copy rule window **************") 
            driver.quit()
            assert False
        cc.setTxtBoxField(self.txtbox_copyRuleName_xpath, rul1Name)
        cc.wait(2)
        cc.randomClick(self.button_copyRuleSetOk_xpath)
        if(cc.checkElement(5, self.label_duplicateRuleError_xpath)):
            DesignerPage.logger.info("******** User is displayed with duplicate rule name error message **************")
            assert True
        else:
            driver.save_screenshot(".\\PCMCS_Jet_DesignerCard\\ScreenShots\\" + testCaseName+".png")   
            DesignerPage.logger.info("******** User is not displayed with duplicate rule name error message **************")
            driver.quit()
            assert False
        cc.wait(2)
        cc.randomClick(self.button_duplicateRuleEOkBtn_xpath)
        cc.wait(2)
        cc.randomClick(self.txtbox_copyRuleName_xpath)
        DesignerPage.logger.info("******** User is entering unique rule name**************")
        cc.setTxtBoxField(self.txtbox_copyRuleName_xpath, rul2Name)
        cc.wait(2)
        cc.randomClick(self.label_copyRuleHdng_xpath)
        cc.randomClick(self.button_copyRuleSetOk_xpath)
        DesignerPage.logger.info("******** User is navigating to the designer screen to check copy rule is success**************")
        cc.wait(8)
        if(AllocRule==True):
            if(cc.checkElement(2, self.label_copiedAllocRule)):
                cc.randomClick(self.label_copiedAllocRule)
                DesignerPage.logger.info("******** Alloc Rule Copied Successfully **************")
                driver.quit()
                assert True
        elif(AllocRule==False):
            if(cc.checkElement(2, self.label_copiedCustomRule)):
                cc.randomClick(self.label_copiedCustomRule)
                DesignerPage.logger.info("********Custom Rule Copied Successfully **************")
                driver.quit()
                assert True               
        else:
            driver.save_screenshot(".\\PCMCS_Jet_DesignerCard\\ScreenShots\\" + testCaseName+".png")   
            DesignerPage.logger.info("******** Rule not Copied Successfully **************")
            driver.quit()
            assert False
    
    def checkrscValidations(self,driver,rscName,rscDesc,rscDimMem,testCaseName):  
        DesignerPage.logger.info("******** Non Level 0 member validation for rule set context dimension **************")  
        cc=commonComponents(driver)
        cc.randomClick(self.link_plusicon_xpath)
        cc.wait(3)
        cc.randomClick(self.item_ruleSet_xpath)
        cc.wait(15)
        cc.setTxtBoxField(self.txtbox_ruleSetField_xpath, rscName)
        cc.setTxtBoxField(self.txtbox_ruleSetDesc_xpath, rscDesc)
        cc.randomClick(self.checkbox_enableRuleSet_xpath)
        cc.wait(3)
        cc.randomClick(self.text_dimensionHeading_xpath)
        cc.wait(6)
        cc.randomClick(self.button_addRSCDimension_xpath)
        cc.wait(1)
        cc.randomClick(self.link_rscDimSelection_xpath)
        cc.setTxtField(self.link_rscDimMemSelection_xpath, self.txtbox_rscDimMemSelection_xpath, rscDimMem)
        cc.typeEnter(2, self.txtbox_rscDimMemSelection_xpath, Keys.ENTER)
        DesignerPage.logger.info("******** User has entered non level 0 member R2 for rsc member selection **************")
        cc.randomClick(self.button_rscDimSaveClose_xpath)
        driver.save_screenshot(".\\PCMCS_Jet_DesignerCard\\ScreenShots\\" + testCaseName+".png")
        cc.wait(3)
        cc.randomClick(self.button_ruleSetInfoOk_xpath)
        DesignerPage.logger.info("******** User should not be allowed to selected non level 0 member **************")
        driver.quit()
        
        
    def copyRuleSet_withandwithOutRules(self,driver,copyrscName,copyYN,prefix,testCaseName):
        
        cc=commonComponents(driver)
        cc.wait(8)
        DesignerPage.logger.info("******** User is selecting existing rule set **************")  
        if (cc.checkElement(1,self.label_existingRuleSet_xpath)):
            DesignerPage.logger.info("******** Existing rule set is available for copying  **************")
            assert True
        
        else:
            driver.save_screenshot(".\\PCMCS_Jet_DesignerCard\\ScreenShots\\" + testCaseName+".png")
            DesignerPage.logger.info("******** Existing rule set is not available for copying  **************")
            driver.quit()
            assert False
        
        cc.randomClick(self.label_existingRuleSet_xpath)
        cc.wait(2)
        if (cc.checkElement(1, self.link_copyImage_xpath)):
            DesignerPage.logger.info("******** Copy Button is displayed **************")
            assert True
            
        else:
            driver.save_screenshot(".\\PCMCS_Jet_DesignerCard\\ScreenShots\\" + testCaseName+".png")
            DesignerPage.logger.info("******** Copy Button is not displayed **************")
            driver.quit()
            assert False
        DesignerPage.logger.info("******** clicking on copy image **************")
        cc.randomClick(self.link_copyImage_xpath)
        cc.wait(4)
        if(cc.checkElement(1, self.label_copyRuleSetHeading_xpath)):
            DesignerPage.logger.info("********Copy Rule Set Window is displayed to the user**************")
            assert True
            
        else:
            driver.save_screenshot(".\\PCMCS_Jet_DesignerCard\\ScreenShots\\" + testCaseName+".png")
            DesignerPage.logger.info("******** Copy Rule Set Window is not displayed to the user **************")
            driver.quit()
            assert False
        
        cc.setTxtBoxField(self.txtbox_copyRuleSetName_xpath, copyrscName)
        cc.wait(4)
        
        if (copyYN==False):
            prefixTxtBoxStatus=bool(cc.checkEnabled(self.txtbox_prefixRuleName_xpath))
            DesignerPage.logger.info(prefixTxtBoxStatus)
            if(prefixTxtBoxStatus):
                driver.save_screenshot(".\\PCMCS_Jet_DesignerCard\\ScreenShots\\" + testCaseName+".png")
                DesignerPage.logger.info("******** Prefix text box is not disabled for user **************")
                driver.quit()
                assert False
            
            else:
                DesignerPage.logger.info("******** Prefix text box is disabled for user **************")
                assert True
            cc.randomClick(self.button_copyRuleSetOk_xpath)
            cc.wait(2)
            if(cc.checkElement(1, self.label_copiedRuleSet_xpath)):
                DesignerPage.logger.info("********Copied ruleset with out rules existing on the page  **************")
                driver.quit()
                assert True
            else:
                driver.save_screenshot(".\\PCMCS_Jet_DesignerCard\\ScreenShots\\" + testCaseName+".png")
                DesignerPage.logger.info("********Copied ruleset without rules is not on the page  **************")
                driver.quit()
                assert False
                
        elif(copyYN==True):
            
            cc.randomClick(self.checkbox_copyRulesChkBox_xpath)
            DesignerPage.logger.info("****** Copy Rules Checkbox is checked *************")
            cc.wait(5)
            cc.randomClick(self.txtbox_prefixRuleName_xpath)
            prefixTxtBoxStatus=bool(cc.checkEnabled(self.txtbox_prefixRuleName_xpath))
            DesignerPage.logger.info(prefixTxtBoxStatus)
            if(prefixTxtBoxStatus):
                DesignerPage.logger.info("******** Prefix text box is enabled for user **************")
                assert True
            else:
                driver.save_screenshot(".\\PCMCS_Jet_DesignerCard\\ScreenShots\\" + testCaseName+".png")
                DesignerPage.logger.info("******** Prefix text box is not enabled for user **************")
                driver.quit()
                assert False
            DesignerPage.logger.info("******* User is entering prefix value for copied rules**********")    
            cc.setTxtBoxField(self.txtbox_prefixRuleName_xpath,prefix)
            DesignerPage.logger.info("******* User entered prefix value for copied rules**********")  
            cc.randomClick(self.button_copyRuleSetOk_xpath)
            cc.wait(5)
            if(cc.checkElement(1, self.label_copiedRuleSet1_xpath)):
                DesignerPage.logger.info("********Copied ruleset with rules existing on the page  **************")
                driver.quit()
                assert True
            else:
                driver.save_screenshot(".\\PCMCS_Jet_DesignerCard\\ScreenShots\\" + testCaseName+".png")
                DesignerPage.logger.info("********Copied ruleset with rules is not existing on the page  **************")
                driver.quit()
                assert False
    
    def editRuleSet(self,driver,testCaseName):
        cc=commonComponents(driver)
        cc.wait(1)
        DesignerPage.logger.info("********User is clicking on the existing rule set to edit and make it disable  **************")
        if (cc.checkElement(1,self.label_existingRuleSet_xpath)):
            DesignerPage.logger.info("******** Existing rule set is available for editing  **************")
            assert True
        
        else:
            driver.save_screenshot(".\\PCMCS_Jet_DesignerCard\\ScreenShots\\" + testCaseName+".png")
            DesignerPage.logger.info("******** Existing rule set is not available for editing  **************")
            driver.quit()
            assert False
        cc.randomClick(self.label_existingRuleSet_xpath)
        cc.wait(2)
        DesignerPage.logger.info("********User is clicking on edit link   **************")
        cc.wait(2)
        cc.randomClick(self.link_editButton_xpath)
        cc.wait(15)
        if(cc.checkElement(5, self.label_editRuleSettxt)):
            DesignerPage.logger.info("********Edit Rule Set Heading is displayed to the user **************")
            assert True
        
        else:
            driver.save_screenshot(".\\PCMCS_Jet_DesignerCard\\ScreenShots\\" + testCaseName+".png") 
            DesignerPage.logger.info("******** Edit Rule Set Heading is not displayed to the user  **************")
            driver.quit()
            assert False
        DesignerPage.logger.info("********User is disabling the rule set**************")
        cc.wait(3)
        cc.randomClick(self.checkbox_enableRuleSet_xpath)
        cc.wait(3)
        cc.randomClick(self.button_rscDimSaveClose_xpath)
        cc.wait(2)
        cc.randomClick(self.button_ruleSetInfoOk_xpath)
        DesignerPage.logger.info("******** clicked on ok button **************")
        cc.wait(2)
        cc.randomClick(self.label_existingRuleSet_xpath)
        if(cc.checkElement(4, self.label_enableStatustxt)):
            DesignerPage.logger.info("********Rule Set is disabled correctly**************")
            driver.quit()
            assert True
        
        else:
            driver.save_screenshot(".\\PCMCS_Jet_DesignerCard\\ScreenShots\\" + testCaseName+".png") 
            DesignerPage.logger.info("********Rule Set is not disabled**************")
            driver.quit()
            assert False
            
    def deleteRuleSet(self,driver,testCaseName):
        cc=commonComponents(driver)
        cc.wait(1)
        DesignerPage.logger.info("********User is clicking on the existing rule set to delete  **************")
        if (cc.checkElement(1,self.label_existingRuleSet_xpath)):
            DesignerPage.logger.info("******** Existing rule set is available for delete  **************")
            assert True
        
        else:
            driver.save_screenshot(".\\PCMCS_Jet_DesignerCard\\ScreenShots\\" + testCaseName+".png")
            DesignerPage.logger.info("******** Existing rule set is not available for delete  **************")
            driver.quit()
            assert False
        
        cc.randomClick(self.label_existingRuleSet_xpath)
        cc.wait(3)
        cc.randomClick(self.link_deleteButton_xpath)
        if(cc.checkElement(10, self.label_deleteRuleSetTxt_xpath)):
            DesignerPage.logger.info("******** User is displayed with delete rule set message  **************")
            assert True
        
        else:
            driver.save_screenshot(".\\PCMCS_Jet_DesignerCard\\ScreenShots\\" + testCaseName+".png")
            DesignerPage.logger.info("******** User is not displayed with delete rule set message  **************")
            driver.quit()
            assert False
        
        cc.wait(5)
        DesignerPage.logger.info("******** User is clicking on ok button to delete rule set  **************")
        cc.randomClick(self.button_deleteRuleSetYes_xpath)
        driver.quit()
    
    def ruleSetHelpLinkValidation(self,driver,helpYN,testCaseName):
        cc=commonComponents(driver)
        cc.wait(5)
        DesignerPage.logger.info("********User is clicking on the existing rule set to navigate to help  **************")
        cc.randomClick(self.label_existingRuleSet2_xpath)
        cc.wait(3)
        cc.randomClick(self.link_editButton_xpath)
        cc.wait(13)
        cc.randomClick(self.label_editRuleSettxt)
        cc.wait(5)
        #cc.randomClick(self.image_helpIcon_xpath)
        if(cc.checkElement(10, self.image_helpIcon_xpath)):
            DesignerPage.logger.info("********User is displayed with help icon  **************")
            assert True
        else:
            driver.save_screenshot(".\\PCMCS_Jet_DesignerCard\\ScreenShots\\" + testCaseName+".png")
            DesignerPage.logger.info("********User is not displayed with help icon  **************")
            driver.quit()
            assert False
        cc.wait(5)
        DesignerPage.logger.info("********User is clikcing on help icon  **************")
        cc.randomClick(self.image_helpIcon_xpath)
        cc.wait(3)
        parentWindowTitle=driver.title
        DesignerPage.logger.info("********The current page title is :"  +  parentWindowTitle)
        if(helpYN==True):
            current_Page=driver.current_window_handle
            DesignerPage.logger.info("*User is clicking on help link *************")
            cc.randomClick(self.link_helpLink_xpath)
            cc.wait(3)
            window_Handles = driver.window_handles
            new_Page=[x for x in window_Handles if x != current_Page][0]
            driver.switch_to_window(new_Page)
            childWindowTitle=driver.title
            DesignerPage.logger.info("********The help page title is :"  +  childWindowTitle)
            if(childWindowTitle=="Getting Started with Profitability and Cost Management"):
                DesignerPage.logger.info("********User successfully navigated to the help page **************")
                assert True
            else:
                driver.save_screenshot(".\\PCMCS_Jet_DesignerCard\\ScreenShots\\" + testCaseName+".png")
                DesignerPage.logger.info("********User did not navigated to the help page **************")
                driver.quit()
                assert False
        else:
            current_Page=driver.current_window_handle
            DesignerPage.logger.info("*User is clicking on help on this link *************")
            cc.randomClick(self.link_helpOnThis_xpath)
            cc.wait(3)
            window_Handles = driver.window_handles
            new_Page=[x for x in window_Handles if x != current_Page][0]
            driver.switch_to_window(new_Page)
            childWindowTitle=driver.title
            DesignerPage.logger.info("********The help page title is :"  +  childWindowTitle)
            if(childWindowTitle=="Getting Started with Profitability and Cost Management"):
                DesignerPage.logger.info("********User successfully navigated to the help page **************")
                assert True
            else:
                driver.save_screenshot(".\\PCMCS_Jet_DesignerCard\\ScreenShots\\" + testCaseName+".png")
                DesignerPage.logger.info("********User did not navigated to the help page **************")
                driver.quit()
                assert False           
        if(cc.checkElement(10, self.label_helpPageText)):
            DesignerPage.logger.info("********User is displayed with Table of contents option  **************")
            driver.quit()
            assert True
        else:
            driver.save_screenshot(".\\PCMCS_Jet_DesignerCard\\ScreenShots\\" + testCaseName+".png")
            DesignerPage.logger.info("********User is not displayed with Table of contents option  **************")
            driver.quit()
            assert False     
            
    def ruleHelpLinkValidation(self,driver,AllocRule,helpYN,testCaseName):
        DesignerPage.logger.info("******** User is clicking on the existing rule to navigate to help **************")
        cc=commonComponents(driver)
        cc.wait(8)
        cc.randomClick(self.label_existingRuleSet3_xpath)
        cc.wait(14)
        cc.randomClick(self.link_expandRuleSet_xpath)
        cc.wait(6)
        if(AllocRule==True):
            cc.randomClick(self.label_copiedAllocRule)
        else:
            cc.randomClick(self.label_copiedCustomRule)
        cc.wait(3)
        cc.randomClick(self.link_editButton_xpath)
        cc.wait(8)
        if(cc.checkElement(5, self.label_editAllocRuleHdng_xpath)):
            DesignerPage.logger.info("******** User is displayed with edit alloc rule page **************")
            assert True
        else:
            driver.save_screenshot(".\\PCMCS_Jet_DesignerCard\\ScreenShots\\" + testCaseName+".png")
            DesignerPage.logger.info("******** User is not displayed with edit alloc rule page **************")
            driver.quit()
            assert False     
        cc.wait(5)
        cc.randomClick(self.label_editAllocRuleHdng_xpath)
        cc.wait(5)
        #cc.randomClick(self.image_helpIcon_xpath)
        if(cc.checkElement(10, self.image_helpIcon_xpath)):
            DesignerPage.logger.info("********User is displayed with help icon  **************")
            assert True
        else:
            driver.save_screenshot(".\\PCMCS_Jet_DesignerCard\\ScreenShots\\" + testCaseName+".png")
            DesignerPage.logger.info("********User is not displayed with help icon  **************")
            driver.quit()
            assert False
        cc.wait(5)
        DesignerPage.logger.info("********User is clikcing on help icon  **************")
        cc.randomClick(self.image_helpIcon_xpath)
        cc.wait(3)
        parentWindowTitle=driver.title
        DesignerPage.logger.info("********The current page title is :"  +  parentWindowTitle)
        current_Page=driver.current_window_handle
        if(helpYN==True):
            DesignerPage.logger.info("********User is clikcing on help link  **************")
            cc.randomClick(self.link_helpLink_xpath)
            cc.wait(3)
            window_Handles = driver.window_handles
            new_Page=[x for x in window_Handles if x != current_Page][0]
            driver.switch_to_window(new_Page)
            cc.wait(2)
            childWindowTitle=driver.title
            DesignerPage.logger.info("********The help page title is :"  +  childWindowTitle)
            if(childWindowTitle=="Getting Started with Profitability and Cost Management"):
                DesignerPage.logger.info("********User successfully navigated to the help page **************")
                assert True
            else:
                driver.save_screenshot(".\\PCMCS_Jet_DesignerCard\\ScreenShots\\" + testCaseName+".png")
                DesignerPage.logger.info("********User did not navigated to the help page **************")
                driver.quit()
                assert False
        else:
            DesignerPage.logger.info("********User is clicking on help on this topic link  **************")
            cc.randomClick(self.link_helpOnThis_xpath)
            cc.wait(3)
            window_Handles = driver.window_handles
            new_Page=[x for x in window_Handles if x != current_Page][0]
            driver.switch_to_window(new_Page)
            cc.wait(2)
            childWindowTitle=driver.title
            DesignerPage.logger.info("********The help page title is :"  +  childWindowTitle)
            if(childWindowTitle=="Getting Started with Profitability and Cost Management"):
                DesignerPage.logger.info("********User successfully navigated to the help page **************")
                assert True
            else:
                driver.save_screenshot(".\\PCMCS_Jet_DesignerCard\\ScreenShots\\" + testCaseName+".png")
                DesignerPage.logger.info("********User did not navigated to the help page **************")
                driver.quit()
                assert False  
                          
        if(cc.checkElement(10, self.label_helpPageText)):
            DesignerPage.logger.info("********User is displayed with Table of contents option  **************")
            driver.quit()
            assert True
        else:
            driver.save_screenshot(".\\PCMCS_Jet_DesignerCard\\ScreenShots\\" + testCaseName+".png")
            DesignerPage.logger.info("********User is not displayed with Table of contents option  **************")
            driver.quit()
            assert False       
             
        
        
    
        
        
        
        
        
        


            
        
            
        

            

        
        


        
        
        
        
        
        
        
            
        
        

        
        
        
        
        
    
     
    