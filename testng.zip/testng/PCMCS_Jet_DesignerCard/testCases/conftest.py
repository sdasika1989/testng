from selenium import webdriver
import pytest
from utilities.customLogger import logGen
#from utilities.readProperties import ReadConfig
#from pageObjects.commonComponents import commonComponents
import os


class DriverUtility:
    
    logger = logGen.logggen()
  
    def getDriver(self,browser):
        global driver
        if browser == 'chrome':
            DriverUtility.logger.info("****test case is running on chrome browser ******")
            #from commandline
            #PATH=".//driverexe//chromedriver.exe"
            #from eclipse
            #PATH="..//driverexe//chromedriver.exe"
            #driver = webdriver.Chrome(PATH)
            DriverUtility.logger.info("****Test Cases are running on Remote Machine ******")
            driver = webdriver.Remote(command_executor='http://slc15zgi.us.oracle.com:4442/wd/hub', desired_capabilities={'browserName': 'chrome', 'javascriptEnabled': True})
        
        elif browser == 'firefox':
            DriverUtility.logger.info("****test case is running on firefox browser ******")
            driver = webdriver.Firefox()
        
        return driver
"""
def pytest_addoption(parser): # This will get value from CLI/hooks
    parser.addoption("--browser")

@pytest.fixture()
def browser(request): # This will return the Browser value to setup method
    return request.config.getoption("--browser")

"""
###### This block of code is for customizing the html report #########

def pytest_configure(config):
    config._metadata['Project Name'] = 'PCMCS'
    config._metadata['Module Name'] = 'JET_UI'
    config._metadata['Tester'] = 'Automation'



@pytest.mark.hookwrapper
def pytest_runtest_makereport(item):

    #Extends the PyTest Plugin to take and embed screenshot in html report, whenever test fails.
    #:param item:
    #cc=commonComponents()
    pytest_html = item.config.pluginmanager.getplugin('html')
    outcome = yield
    report = outcome.get_result()
    extra = getattr(report, 'extra', [])
    
    if report.when == 'call' or report.when == "setup":
        xfail = hasattr(report, 'wasxfail')
        if (report.skipped and xfail) or (report.failed and not xfail):
            
            file_name = report.nodeid.replace("::", "_")+".png"
            #testCases/test_login.py_Test_WaterFallSetup_test03_homePageTitle.png
            
            fileNameAsList = file_name.split("_");
            DriverUtility.logger.info(fileNameAsList)
            fileNameAsList.reverse();
            file_name = str(fileNameAsList[1])+"_"+str(fileNameAsList[0]);
            DriverUtility.logger.info(file_name)
            #driver.save_screenshot(".\\ScreenShots\\" + file_name)
            #driver.quit()
            filepath = os.getcwd()
            DriverUtility.logger.info(filepath)
            file_name=filepath +"/ScreenShots/" + file_name

            if file_name:
                html = '<div><img src="%s" alt="screenshot" style="width:304px;height:228px;" ' \
                       'onclick="window.open(this.src)" align="right"/></div>' % file_name
                extra.append(pytest_html.extras.html(html))
                
        report.extra = extra
        
        #sys.getProperty("user.dir")



"""
def _capture_screenshot(name):
    #driver=DriverUtility.getDriver(ReadConfig.getBrowser())
    driver.get_screenshot_as_file(name)
"""

