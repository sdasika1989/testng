import pytest
import sys
from selenium import webdriver
from pageObjects.LoginPage import LoginPage
from pageObjects.DesignerPage import DesignerPage
from time import sleep
from Rest.importTemplateConsumer import ImportTemplate
from utilities.readProperties import ReadConfig
from utilities.customLogger import logGen
from Rest.deleteApplication import DeleteApplication 
from utilities.fileUploadUtilities import FileUploadUtilities 
from utilities.propertiesUtils import PropertiesUtils 
from pageObjects.commonComponents import commonComponents
from testCases.conftest import DriverUtility
import os
from unittest.loader import getTestCaseNames
#import HtmlTestRunner
#import unittest

class Test_WaterFallSetup:
    
    
    prop = PropertiesUtils()
    server=ReadConfig.getServer()
    username=ReadConfig.getUser()
    password=ReadConfig.getPassword()
    logger = logGen.logggen()
    delApp = DeleteApplication()
    impTemplate = ImportTemplate()
    uploadFile = FileUploadUtilities()
    gd = DriverUtility()
    filepath=os.getcwd()
    modelName= ReadConfig.getModelName()
    browser=ReadConfig.getBrowser()
    profitURL= prop.getProfitURL()
   
    
    
    def test01_environmentsetup(self):
        Test_WaterFallSetup.logger.info("****** test01_environmentsetup *******")
        Test_WaterFallSetup.logger.info("******Initial Environment Setup Process is starting *******")
        Test_WaterFallSetup.logger.info("******Deleting any existing application is present on the server *******")
        Test_WaterFallSetup.delApp.deleteApplication()
        Test_WaterFallSetup.logger.info("****** Delete existing application process is completed *******")
        Test_WaterFallSetup.logger.info("****** Uploading the requied model into the server *******")
        Test_WaterFallSetup.uploadFile.uploadFileOverwrite("profitinbox", Test_WaterFallSetup.modelName,"template.zip")
        Test_WaterFallSetup.impTemplate.importTemplate()
        Test_WaterFallSetup.logger.info("****** Environment set up is completed now UI test will be started *******")
    
    
    
    def test02_loginPageTitle(self):
        Test_WaterFallSetup.logger.info("******** test02_loginPageTitle **************")
        Test_WaterFallSetup.logger.info("***Verifying login page title*********")
        driver = Test_WaterFallSetup.gd.getDriver(Test_WaterFallSetup.browser)
        driver.get(Test_WaterFallSetup.profitURL)
        sleep(8)
        act_title = driver.title
        Test_WaterFallSetup.logger.info("The actual login page title is :" + act_title )
        if (act_title == "Sign In To ORACLE CLOUD" or act_title == "Identity Cloud Service"):
            assert True
            Test_WaterFallSetup.logger.info("****Login Page Title is Passed *********")
            driver.quit()
            
        else:
            #Test_WaterFallSetup.logger.error("this is from testcase " + Test_WaterFallSetup.filepath)
            driver.save_screenshot( ".//PCMCS_Jet_DesignerCard//ScreenShots//" + "test02_loginPageTitle.png")
            Test_WaterFallSetup.logger.error("****Login Page Title is failed *********")
            driver.quit()
            assert False
            
      
    
    def test03_homePageTitle(self):
        Test_WaterFallSetup.logger.info("******** test03_homePageTitle **************")
        Test_WaterFallSetup.logger.info("*** Verifying application home page title *********")
        driver = Test_WaterFallSetup.gd.getDriver(Test_WaterFallSetup.browser)
        driver.get(Test_WaterFallSetup.profitURL)
        driver.maximize_window()
        Test_WaterFallSetup.lp = LoginPage(driver)
        sleep(5)
        Test_WaterFallSetup.lp.setUserName(Test_WaterFallSetup.username)
        Test_WaterFallSetup.lp.setPassword(Test_WaterFallSetup.password)
        Test_WaterFallSetup.lp.clickLogin()
        sleep(5)
        act_title=driver.title
        #Test_WaterFallSetup.logger.info(act_title)
        Test_WaterFallSetup.logger.info("The actual home page title is :" + act_title )
        if (act_title=="Profitability Login" or act_title=="Profitability" or act_title=="EPM Cloud Profitability and Cost Management") :
            Test_WaterFallSetup.logger.info("****Application home Page Title is Passed *********")
            assert True
        
        else:
            driver.save_screenshot(".//PCMCS_Jet_DesignerCard//ScreenShots//" + "test03_homePageTitle.png")
            Test_WaterFallSetup.logger.error("****Application home Page Title is failed *********")
            driver.quit()
            assert False
        
        
        if (Test_WaterFallSetup.lp.checkElementPresent(10)):
            Test_WaterFallSetup.logger.info("*** Home Icon is present on the application home page *********")
            driver.quit()
            assert True
        
        else:
            driver.save_screenshot(".//PCMCS_Jet_DesignerCard//ScreenShots//" + "test03_homePageTitle.png")
            Test_WaterFallSetup.logger.info("*** Home Icon is not present on the application home page *********")
            driver.quit()
            assert False
            
    
    
    def test04_createRSCGCSelectedtxtField(self):
        Test_WaterFallSetup.logger.info("*** test04_CreateRSC_GCSelected *********")
        driver = Test_WaterFallSetup.gd.getDriver(Test_WaterFallSetup.browser)
        cc = commonComponents(driver)
        dp = DesignerPage(driver)
        cc.navigateWaterfallScreen(driver,"test04_createRSCGCSelectedtxtField")
        dp.createRSC(driver, "ruleSet1", "creating rule set","Yes",False,"R21","test04_createRSC_GCSelected_txtField")
        
    def test11_createRSCGCSelectedmemSelector(self):
        Test_WaterFallSetup.logger.info("*** test11_CreateRSC_GCSelected *********")
        driver = Test_WaterFallSetup.gd.getDriver(Test_WaterFallSetup.browser)
        cc = commonComponents(driver)
        dp = DesignerPage(driver)
        cc.navigateWaterfallScreen(driver,"test11_createRSCGCSelectedmemSelector")
        dp.createRSC(driver, "ruleSet2", "creating rule set","Yes",True,"R21","test11_createRSC_GCSelected_memSelector")
        
    def test12_createRSCGCSelectedNo(self):
        Test_WaterFallSetup.logger.info("*** test12_CreateRSC_GCSelectedNo *********")
        driver = Test_WaterFallSetup.gd.getDriver(Test_WaterFallSetup.browser)
        cc = commonComponents(driver)
        dp = DesignerPage(driver)
        cc.navigateWaterfallScreen(driver,"test12_createRSCGCSelectedNo")
        dp.createRSC(driver, "ruleSet3", "creating rule set with no RSC","No",True,"R21","test12_createRSC_GCSelectedNo")
      
     
    def test05_createRSCrscValidationsNonLevel0(self):
        Test_WaterFallSetup.logger.info("*** test05_CreateRSC_rscValidations_NonLevel0 *********")
        driver = Test_WaterFallSetup.gd.getDriver(Test_WaterFallSetup.browser)
        cc = commonComponents(driver)
        dp = DesignerPage(driver)
        cc.navigateWaterfallScreen(driver,"test05_createRSCrscValidationsNonLevel0")
        dp.checkrscValidations(driver, "ruleSet2", "checking for non level 0 member", "R2","test05_createRSC_rscValidations_NonLevel0")
    
    
    def test06_copyRuleSetwithOutRules(self):
        Test_WaterFallSetup.logger.info("*** test06_copyRuleSet_withOutRules *********")
        driver = Test_WaterFallSetup.gd.getDriver(Test_WaterFallSetup.browser)
        cc = commonComponents(driver)
        dp = DesignerPage(driver)
        cc.navigateWaterfallScreen(driver,"test06_copyRuleSetwithOutRules")
        dp.copyRuleSet_withandwithOutRules(driver, "Copied Rule Set",False,"copy","test06_copyRuleSetwithOutRules")
        
    def test07_copyRuleSetwithRules(self):
        Test_WaterFallSetup.logger.info("*** test07_copyRuleSet_withRules *********")
        driver = Test_WaterFallSetup.gd.getDriver(Test_WaterFallSetup.browser)
        cc = commonComponents(driver)
        dp = DesignerPage(driver)
        cc.navigateWaterfallScreen(driver,"test07_copyRuleSetwithRules")
        dp.copyRuleSet_withandwithOutRules(driver, "Copied Rule Set1",True,"copy","test07_copyRuleSetwithRules") 
        
    
    def test08_editRuleSet(self):
        Test_WaterFallSetup.logger.info("*** test08_editRuleSet *********")
        driver = Test_WaterFallSetup.gd.getDriver(Test_WaterFallSetup.browser)
        cc = commonComponents(driver)
        dp = DesignerPage(driver)
        cc.navigateWaterfallScreen(driver,"test08_editRuleSet")
        dp.editRuleSet(driver,"test08_editRuleSet")
        Test_WaterFallSetup.logger.info("*** User is able to edit rule set successfully *********")
    
    def test09_deleteRuleSet(self):
        Test_WaterFallSetup.logger.info("*** test09_deleteRuleSet *********")
        driver = Test_WaterFallSetup.gd.getDriver(Test_WaterFallSetup.browser)
        cc = commonComponents(driver)
        dp = DesignerPage(driver)
        cc.navigateWaterfallScreen(driver,"test09_deleteRuleSet")
        dp.deleteRuleSet(driver,"test09_deleteRuleSet")
        Test_WaterFallSetup.logger.info("*** User is able to delete rule set successfully *********")  
        
    def test10_helpLinkRuleSet(self):
        Test_WaterFallSetup.logger.info("*** test10_helpLinkRuleSet *********")
        driver = Test_WaterFallSetup.gd.getDriver(Test_WaterFallSetup.browser)
        cc = commonComponents(driver)
        dp = DesignerPage(driver)
        cc.navigateWaterfallScreen(driver,"test10_helpLinkRuleSet")  
        dp.ruleSetHelpLinkValidation(driver,True,"test10_helpLinkRuleSet")
        
    def test20_helpOnThisTopicRuleSet(self):
        Test_WaterFallSetup.logger.info("*** test20_helpLinkRuleSet *********")
        driver = Test_WaterFallSetup.gd.getDriver(Test_WaterFallSetup.browser)
        cc = commonComponents(driver)
        dp = DesignerPage(driver)
        cc.navigateWaterfallScreen(driver,"test20_helpOnThisTopicRuleSet")  
        dp.ruleSetHelpLinkValidation(driver,False,"test20_helpOnThisTopicRuleSet")
    
    def test13_createAllocRuleTxtFields(self):
        Test_WaterFallSetup.logger.info("*** test13_createAllocRule with dimension members selected through text fields*********")
        driver = Test_WaterFallSetup.gd.getDriver(Test_WaterFallSetup.browser)
        cc = commonComponents(driver)
        dp = DesignerPage(driver)
        cc.navigateWaterfallScreen(driver,"test13_createAllocRuleTxtFields")
        dp.creatAllocRule(driver, "allocRule1", "Create Allocation Rule",False,"X1","Y11","X12","Y12","test13_createAllocRuleTxtFields")

    def test14_createAllocRuleMemSelector(self):
        Test_WaterFallSetup.logger.info("*** test14_createAllocRule with dimensions members selected throug member selector *********")
        driver = Test_WaterFallSetup.gd.getDriver(Test_WaterFallSetup.browser)
        cc = commonComponents(driver)
        dp = DesignerPage(driver)
        cc.navigateWaterfallScreen(driver,"test14_createAllocRuleMemSelector")
        dp.creatAllocRule(driver, "allocRule2", "Create Allocation Rule",True,"X1","Y11","X12","Y12","test14_createAllocRuleMemSelector")
    
    def test15_copyAllocRule(self):
        Test_WaterFallSetup.logger.info("*** test15_copyingAllocationRule *********")
        driver = Test_WaterFallSetup.gd.getDriver(Test_WaterFallSetup.browser)
        cc = commonComponents(driver)
        dp = DesignerPage(driver)
        cc.navigateWaterfallScreen(driver,"test15_copyAllocRule")
        dp.copyRule(driver, True,"allocRule2","allocRule3","test15_copyAllocRule")
        
    def test16_editAllocRule(self):
        Test_WaterFallSetup.logger.info("*** test16_editAllocRule *********")
        driver = Test_WaterFallSetup.gd.getDriver(Test_WaterFallSetup.browser)
        cc = commonComponents(driver)
        dp = DesignerPage(driver)
        cc.navigateWaterfallScreen(driver,"test16_editAllocRule")
        dp.editRule(driver,True,"test16_editAllocRule")

    def test17_deleteAllocRule(self):
        Test_WaterFallSetup.logger.info("*** test17_deleteAllocRule *********")
        driver = Test_WaterFallSetup.gd.getDriver(Test_WaterFallSetup.browser)
        cc = commonComponents(driver)
        dp = DesignerPage(driver)
        cc.navigateWaterfallScreen(driver,"test17_deleteAllocRule")
        dp.deleteRule(driver,True,"test17_deleteAllocRule")

    def test18_helpLinkAllocRule(self):
        Test_WaterFallSetup.logger.info("*** test18_helpLinkAllocRule *********")
        driver = Test_WaterFallSetup.gd.getDriver(Test_WaterFallSetup.browser)
        cc = commonComponents(driver)
        dp = DesignerPage(driver)
        cc.navigateWaterfallScreen(driver,"test18_helpLinkAllocRule")  
        dp.ruleHelpLinkValidation(driver,True,True,"test18_helpLinkAllocRule")   
    
    def test19_helpOnThisTopicAllocRule(self):
        Test_WaterFallSetup.logger.info("*** test19_helponthistopicAllocRule *********")
        driver = Test_WaterFallSetup.gd.getDriver(Test_WaterFallSetup.browser)
        cc = commonComponents(driver)
        dp = DesignerPage(driver)
        cc.navigateWaterfallScreen(driver,"test19_helpOnThisTopicAllocRule")  
        dp.ruleHelpLinkValidation(driver,True,False,"test19_helpOnThisTopicAllocRule")     
    
    def test21_createCustomRule(self):
        Test_WaterFallSetup.logger.info("*** test21_createCustomRule *********")
        driver = Test_WaterFallSetup.gd.getDriver(Test_WaterFallSetup.browser)
        cc = commonComponents(driver)
        dp = DesignerPage(driver)
        cc.navigateWaterfallScreen(driver,"test21_createCustomRule")  
        dp.createCustomRule(driver, "customRule1", "creating custom Rule", "[Input]:= ([Allocation In],[R0001])*0.15;", "X1", "Y1",'NO',"","","test21_createCustomRule")     

    def test22_copyCustomRule(self):
        Test_WaterFallSetup.logger.info("*** test22_copyingCustomRule *********")
        driver = Test_WaterFallSetup.gd.getDriver(Test_WaterFallSetup.browser)
        cc = commonComponents(driver)
        dp = DesignerPage(driver)
        cc.navigateWaterfallScreen(driver,"test22_copyCustomRule")
        dp.copyRule(driver,False, "customRule1","customRule2","test22_copyCustomRule")    
    
    def test23_editCustomRule(self):
        Test_WaterFallSetup.logger.info("*** test23_editCustomRule *********")
        driver = Test_WaterFallSetup.gd.getDriver(Test_WaterFallSetup.browser)
        cc = commonComponents(driver)
        dp = DesignerPage(driver)
        cc.navigateWaterfallScreen(driver,"test23_editCustomRule")
        dp.editRule(driver,False,"test23_editCustomRule")    

    def test24_deleteCustomRule(self):
        Test_WaterFallSetup.logger.info("*** test24_deleteCustomRule *********")
        driver = Test_WaterFallSetup.gd.getDriver(Test_WaterFallSetup.browser)
        cc = commonComponents(driver)
        dp = DesignerPage(driver)
        cc.navigateWaterfallScreen(driver,"test24_deleteCustomRule")
        dp.deleteRule(driver,False,"test24_deleteCustomRule")    
        
    def test25_helpLinkCustomRule(self):
        Test_WaterFallSetup.logger.info("*** test25_helpLinkCustomRule *********")
        driver = Test_WaterFallSetup.gd.getDriver(Test_WaterFallSetup.browser)
        cc = commonComponents(driver)
        dp = DesignerPage(driver)
        cc.navigateWaterfallScreen(driver,"test25_helpLinkCustomRule")  
        dp.ruleHelpLinkValidation(driver,False,True,"test25_helpLinkCustomRule")    

    def test26_helpOnThisTopicCustomRule(self):
        Test_WaterFallSetup.logger.info("*** test25_helpLinkonthistopicCustomRule *********")
        driver = Test_WaterFallSetup.gd.getDriver(Test_WaterFallSetup.browser)
        cc = commonComponents(driver)
        dp = DesignerPage(driver)
        cc.navigateWaterfallScreen(driver,"test26_helpOnThisTopicCustomRule")  
        dp.ruleHelpLinkValidation(driver,False,False,"test26_helpOnThisTopicCustomRule")   
    
    def test27_allocRuleValidations(self):
        Test_WaterFallSetup.logger.info("*** test27_checking validation messages to enable the rule*********")
        driver = Test_WaterFallSetup.gd.getDriver(Test_WaterFallSetup.browser)
        cc = commonComponents(driver)
        dp = DesignerPage(driver)
        cc.navigateWaterfallScreen(driver,"test27_allocRuleValidations")
        dp.allocRuleValidations(driver, "allocRule", "error message validations","test27_allocRuleValidations")
    
    def test28_customRuleValidations(self):
        Test_WaterFallSetup.logger.info("*** test27_checking validation messages to enable the rule*********")
        driver = Test_WaterFallSetup.gd.getDriver(Test_WaterFallSetup.browser)
        cc = commonComponents(driver)
        dp = DesignerPage(driver)
        cc.navigateWaterfallScreen(driver,"test28_customRuleValidations")
        dp.customRuleValidations(driver, "customRule3", "error message validations","[Input]:= ([Allocation In],[R0001])*0.15;","test28_customRuleValidations")   

    def test29_addFilterCustomRule(self):
        Test_WaterFallSetup.logger.info("*** test29_Add Filters Custom Rule*********")
        driver = Test_WaterFallSetup.gd.getDriver(Test_WaterFallSetup.browser)
        cc = commonComponents(driver)
        dp = DesignerPage(driver)
        cc.navigateWaterfallScreen(driver,"test29_addFilterCustomRule")
        dp.addFiltersRule(driver, False, "X11","test29_addFilterCustomRule")
    
    def test30_addFilterAllocRule(self):
        Test_WaterFallSetup.logger.info("*** test30_Add Filters Alloc Rule*********")
        driver = Test_WaterFallSetup.gd.getDriver(Test_WaterFallSetup.browser)
        cc = commonComponents(driver)
        dp = DesignerPage(driver)
        cc.navigateWaterfallScreen(driver,"test30_addFilterAllocRule")
        dp.addFiltersRule(driver, True, "X11","test30_addFilterAllocRule")
    
    def test31_customFormulaValidations(self):
        Test_WaterFallSetup.logger.info("*** test31_CustomFormulaValidations*********")
        driver = Test_WaterFallSetup.gd.getDriver(Test_WaterFallSetup.browser)
        cc = commonComponents(driver)
        dp = DesignerPage(driver)
        cc.navigateWaterfallScreen(driver,"test31_customFormulaValidations")
        dp.createCustomRule(driver, "customRule4", "creating custom Rule", "[Adjustment In]:= ([Rule]) * .15", "X1", "Y1",'YES',"[Input]:= ","[Rule]:= ([Input],[Rule]);","test31_customFormulaValidations")     
    
        
#Test_WaterFallSetup.test01_environmentsetup(print)
#Test_WaterFallSetup.test02_loginPageTitle(print)
#Test_WaterFallSetup.test03_homePageTitle(print)
#Test_WaterFallSetup.test04_createRSC_GCSelected_txtField(print)
#Test_WaterFallSetup.test05_createRSC_rscValidations_NonLevel0(print)
#Test_WaterFallSetup.test06_copyRuleSet_withOutRules(print)
#Test_WaterFallSetup.test07_copyRuleSet_withRules(print)
#Test_WaterFallSetup.test08_editRuleSet(print)
#Test_WaterFallSetup.test09_deleteRuleSet(print)
Test_WaterFallSetup.test10_helpLinkRuleSet(print)
#Test_WaterFallSetup.test11_createRSC_GCSelected_memSelector(print)
#Test_WaterFallSetup.test12_createRSC_GCSelectedNo(print)
#Test_WaterFallSetup.test13_createAllocRule_TxtFields(print)
#Test_WaterFallSetup.test14_createAllocRule_MemSelector(print)
#Test_WaterFallSetup.test15_copyAllocRule(print)
#Test_WaterFallSetup.test16_editAllocRule(print)
#Test_WaterFallSetup.test17_deleteAllocRule(print)
#Test_WaterFallSetup.test18_helpLinkAllocRule(print)
#Test_WaterFallSetup.test19_helpOnThisTopic_AllocRule(print)
#Test_WaterFallSetup.test20_helpOnThisTopicRuleSet(print)
#Test_WaterFallSetup.test21_createCustomRule(print)
#Test_WaterFallSetup.test22_copyCustomRule(print) 
#Test_WaterFallSetup.test23_editCustomRule(print)     
#Test_WaterFallSetup.test24_deleteCustomRule(print)
#Test_WaterFallSetup.test25_helpLink_CustomRule(print)
#Test_WaterFallSetup.test26_helpOnThisTopic_CustomRule(print)
#Test_WaterFallSetup.test27_allocRuleValidations(print)
#Test_WaterFallSetup.test28_customRuleValidations(print)
#Test_WaterFallSetup.test29_addFilter_CustomRule(print)
#Test_WaterFallSetup.test30_addFilter_AllocRule(print)   
#Test_WaterFallSetup.test31_customFormulaValidations(print)

        
        
        
        
        
        
        
        
        