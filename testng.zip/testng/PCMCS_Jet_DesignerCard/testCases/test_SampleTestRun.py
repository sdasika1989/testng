from pageObjects.DesignerPage import DesignerPage
from time import sleep
from Rest.importTemplateConsumer import ImportTemplate
from utilities.readProperties import ReadConfig
from utilities.customLogger import logGen
from Rest.deleteApplication import DeleteApplication 
from utilities.fileUploadUtilities import FileUploadUtilities 
from utilities.propertiesUtils import PropertiesUtils 
from pageObjects.commonComponents import commonComponents
from testCases.conftest import DriverUtility
import os

class Test_WaterFallSetup1:
    
    
    prop = PropertiesUtils()
    server=ReadConfig.getServer()
    username=ReadConfig.getUser()
    password=ReadConfig.getPassword()
    logger = logGen.logggen()
    delApp = DeleteApplication()
    impTemplate = ImportTemplate()
    uploadFile = FileUploadUtilities()
    gd = DriverUtility()
    filepath = os.getcwd()
    modelName= ReadConfig.getModelName()
    browser=ReadConfig.getBrowser()
    profitURL= prop.getProfitURL()
    
    
    
    def test02_loginPageTitle(self):
        Test_WaterFallSetup1.logger.info("******** test02_loginPageTitle **************")
        Test_WaterFallSetup1.logger.info("***Verifying login page title*********")
        driver = Test_WaterFallSetup1.gd.getDriver(Test_WaterFallSetup1.browser)
        driver.get(Test_WaterFallSetup1.profitURL)
        act_title = driver.title
        Test_WaterFallSetup1.logger.info("The actual login page title is :" + act_title )
        if act_title == "Sign In To ORACLE CLOUD1":
            assert True
            Test_WaterFallSetup1.logger.info("****Login Page Title is Passed *********")
            driver.quit()
            
        else:
            driver.save_screenshot(Test_WaterFallSetup1.filepath + "//ScreenShots//" + "test02_loginPageTitle.png")
            Test_WaterFallSetup1.logger.error("****Login Page Title is failed *********")
            driver.quit()
            assert False

#Test_WaterFallSetup1.test02_loginPageTitle(print)
