import pytest
import sys
from selenium import webdriver
from pageObjects.LoginPage import LoginPage
from pageObjects.DesignerPage import DesignerPage
from pageObjects.MassEdit import MassEdit
from time import sleep
from Rest.importTemplateConsumer import ImportTemplate
from utilities.readProperties import ReadConfig
from utilities.customLogger import logGen
from Rest.deleteApplication import DeleteApplication 
from utilities.fileUploadUtilities import FileUploadUtilities 
from utilities.propertiesUtils import PropertiesUtils 
from pageObjects.commonComponents import commonComponents
from testCases.conftest import DriverUtility
from testCases.test_login import Test_WaterFallSetup
import os

#import HtmlTestRunner
#import unittest

class Test_MassEdit:
    
    
    prop = PropertiesUtils()
    server=ReadConfig.getServer()
    username=ReadConfig.getUser()
    password=ReadConfig.getPassword()
    logger = logGen.logggen()
    delApp = DeleteApplication()
    impTemplate = ImportTemplate()
    uploadFile = FileUploadUtilities()
    gd = DriverUtility()
    #wfsetup = Test_WaterFallSetup()
    filepath=os.getcwd()
    modelName= ReadConfig.getModelName()
    browser=ReadConfig.getBrowser()
    profitURL= prop.getProfitURL()
    
    @pytest.mark.massEdit
    def test001_environmentsetup(self):
        Test_MassEdit.logger.info("****** test01_environmentsetup *******")
        Test_MassEdit.logger.info("******Initial Environment Setup Process is starting *******")
        Test_MassEdit.logger.info("******Deleting any existing application is present on the server *******")
        Test_MassEdit.delApp.deleteApplication()
        Test_MassEdit.logger.info("****** Delete existing application process is completed *******")
        Test_MassEdit.logger.info("****** Uploading the requied model into the server *******")
        Test_MassEdit.uploadFile.uploadFileOverwrite("profitinbox", Test_MassEdit.modelName,"template.zip")
        Test_MassEdit.impTemplate.importTemplate()
        Test_MassEdit.logger.info("****** Environment set up is completed now UI test will be started *******")        
    
        
    @pytest.mark.massEdit
    def test002_AddMemberJobSrcLevel0Mbr(self):
        Test_WaterFallSetup.logger.info("*** test002_AddMemberJobSrcLevel0Mbr *********")
        driver = Test_WaterFallSetup.gd.getDriver(Test_WaterFallSetup.browser)
        cc = commonComponents(driver)
        me = MassEdit(driver)
        cc.navigateWaterfallScreen(driver,"test002_AddMemberJobSrcLevel0Mbr")
        cc.navigateMassEditScreen()
        
        me.createAddMemJob(driver, "New_Rule1","test002_AddMemberJobSrcLevel0Mbr","Add Member to Rules","X21","Source","Added X21 member in src section","NO","")
        if(me.isMemberPresent(driver, "Ruleset 2", "New_Rule1","test002_AddMemberJobSrcLevel0Mbr","YES","YES")):
            assert True
            driver.quit()
        else:
            driver.quit()
            assert False
    
    
    @pytest.mark.massEdit
    def test003_AddMemberJobDestLevel0Mbr(self):
        Test_WaterFallSetup.logger.info("*** test003_AddMemberJobDestLevel0Mbr *********")
        driver = Test_WaterFallSetup.gd.getDriver(Test_WaterFallSetup.browser)
        cc = commonComponents(driver)
        me = MassEdit(driver)
        cc.navigateWaterfallScreen(driver,"test003_AddMemberJobDestLevel0Mbr")
        cc.navigateMassEditScreen()
        me.createAddMemJob(driver, "New_Rule1","test003_AddMemberJobDestLevel0Mbr","Add Member to Rules","X11","Destination","Added X11 member in destination section","NO","")
        if(me.isMemberPresent(driver, "Ruleset 2", "New_Rule1","test003_AddMemberJobDestLevel0Mbr","YES","NO")):
            assert True
            driver.quit()
        else:
            driver.quit()
            assert False    
    
    @pytest.mark.massEdit
    def test004_AddMemberJobDriverbasisLevel0Mbr(self):
        Test_WaterFallSetup.logger.info("*** test004_AddMemberJobDriverbasisLevel0Mbr *********")
        driver = Test_WaterFallSetup.gd.getDriver(Test_WaterFallSetup.browser)
        cc = commonComponents(driver)
        me = MassEdit(driver)
        cc.navigateWaterfallScreen(driver,"test004_AddMemberJobDriverbasisLevel0Mbr")
        cc.navigateMassEditScreen()
        me.createAddMemJob(driver, "New_Rule1","test004_AddMemberJobDriverbasisLevel0Mbr","Add Member to Rules","X11","Driver Basis","Added X11 member to driver basis section","NO","")
        if(me.isMemberPresent(driver, "Ruleset 2", "New_Rule1","test004_AddMemberJobDriverbasisLevel0Mbr","NO","NO")):
            assert True
            driver.quit()
        else:
            driver.quit()
            assert False  
    
    @pytest.mark.massEdit
    def test005_AddMemberJobOffsetLevel0Mbr(self):
        Test_WaterFallSetup.logger.info("*** test005_AddMemberJobOffsetLevel0Mbr *********")
        driver = Test_WaterFallSetup.gd.getDriver(Test_WaterFallSetup.browser)
        cc = commonComponents(driver)
        me = MassEdit(driver)
        cc.navigateWaterfallScreen(driver,"test005_AddMemberJobOffsetLevel0Mbr")
        cc.navigateMassEditScreen()
        me.createAddMemJob(driver, "New_Rule1","test005_AddMemberJobOffsetLevel0Mbr","Add Member to Rules","X11","Offset","Added X11 member to offset location section","NO","")
        if(me.isMemberPresent(driver, "Ruleset 2", "New_Rule1","test005_AddMemberJobOffsetLevel0Mbr","YN","NO")):
            assert True
            driver.quit()
        else:
            driver.quit()
            assert False   
    
    @pytest.mark.massEdit
    def test006_AddMemberJobTrgtLevel0Mbr(self):
        Test_WaterFallSetup.logger.info("*** test006_AddMemberJobTrgtLevel0Mbr *********")
        driver = Test_WaterFallSetup.gd.getDriver(Test_WaterFallSetup.browser)
        cc = commonComponents(driver)
        me = MassEdit(driver)
        cc.navigateWaterfallScreen(driver,"test006_AddMemberJobTrgtLevel0Mbr")
        cc.navigateMassEditScreen()
        me.createAddMemJob(driver, "Rule3","test006_AddMemberJobTrgtLevel0Mbr","Add Member to Rules","X11","Target","Added X11 member to X dimension in target location section","NO","")
        if(me.isMemberPresent(driver, "Ruleset 1", "Rule3","test006_AddMemberJobTrgtLevel0Mbr","TRGT","NO")):
            assert True
            driver.quit()
        else:
            driver.quit()
            assert False
            
    @pytest.mark.massEdit
    def test007_AddMemberJobDrvTab2Mbrs(self):
        Test_WaterFallSetup.logger.info("*** test007_AddMemberJobDrvTab2Mbrs -- checking error message *********")
        driver = Test_WaterFallSetup.gd.getDriver(Test_WaterFallSetup.browser)
        cc = commonComponents(driver)
        me = MassEdit(driver)
        cc.navigateWaterfallScreen(driver,"test007_AddMemberJobDrvTab2Mbrs")
        cc.navigateMassEditScreen()
        me.createAddMemJob(driver, "New_Rule2","test007_AddMemberJobDrvTab2Mbrs","Add Member to Rules","X11","Driver Basis","Adding X11 and X12 member to Driver location section","YES","X12")
    
    @pytest.mark.massEdit
    def test008_AddMemberJobOffsetTab2Mbrs(self):
        Test_WaterFallSetup.logger.info("*** test008_AddMemberJobOffsetTab2Mbrs -- checking error message *********")
        driver = Test_WaterFallSetup.gd.getDriver(Test_WaterFallSetup.browser)
        cc = commonComponents(driver)
        me = MassEdit(driver)
        cc.navigateWaterfallScreen(driver,"test008_AddMemberJobOffsetTab2Mbrs")
        cc.navigateMassEditScreen()
        me.createAddMemJob(driver, "New_Rule2","test008_AddMemberJobOffsetTab2Mbrs","Add Member to Rules","X11","Offset","Adding X11 and X12 member to Offset location section","YES","X12")    
    
    @pytest.mark.massEdit
    def test009_copyRulesNewPOV(self):
        Test_WaterFallSetup.logger.info("*** test009_AddMemberJobDrvTab2Mbrs *********")
        driver = Test_WaterFallSetup.gd.getDriver(Test_WaterFallSetup.browser)
        cc = commonComponents(driver)
        me = MassEdit(driver)
        cc.navigateWaterfallScreen(driver,"test009_copyRulesNewPOV")
        cc.navigateMassEditScreen()    
        me.copyRulestoNewPOV(driver, "New_Rule1", "Rule1", "Ruleset 1","Copy Rules to Point of View", "Copying two rules from different rule set into new pov", "test009_copyRulesNewPOV")
        cc.navigatetoWaterfallSetup()
        me.isRulesPresent(driver, 2019, "January", "Actual","Ruleset 1","Rule1","Ruleset 2","New_Rule1","test009_copyRulesNewPOV")

    @pytest.mark.massEdit
    def test010_disableRules(self):
        Test_WaterFallSetup.logger.info("*** test010_disableRules *********")
        driver = Test_WaterFallSetup.gd.getDriver(Test_WaterFallSetup.browser)
        cc = commonComponents(driver)
        me = MassEdit(driver)
        cc.navigateWaterfallScreen(driver,"test010_disableRules")
        cc.navigateMassEditScreen()  
        me.disableRulesSelected(driver, "Rule3", "Rule4", "Disable Rules", "test010_disableRules")
        cc.navigatetoWaterfallSetup()
        me.isRulesDisabled(driver, "Ruleset 1", "Rule3", "Rule4", "test010_disableRules")
    
#Test_MassEdit.test001_environmentsetup(print)
#Test_MassEdit.test002_AddMemberJob_Src_Level0Mbr(print)

        
        
        
        
        
        
        
        
        