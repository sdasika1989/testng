#from jproperties import Properties
from utilities.readProperties import ReadConfig


# Code to read config file properties into the python program
class PropertiesUtils():
    
    server = ReadConfig.getServer()
    port = ReadConfig.getPort()
    version = ReadConfig.getVersion()
    epmapiversion=ReadConfig.getEPMAPIVersion()
    staging = ReadConfig.getStaging()
    oci = ReadConfig.getOCI()
    user = ReadConfig.getUser()
    domain = ReadConfig.getDomain()
        
    def getWebserviceurl(self):
        
        if(PropertiesUtils.staging=="false" and PropertiesUtils.oci =="false"):
        
            serverurl = "http://%s:%s/epm/rest/%s" % (PropertiesUtils.server, PropertiesUtils.port, PropertiesUtils.version)
            print("This is server url: " + serverurl )
        
        else:
            serverurl = "https://%s/epm/rest/%s" % (PropertiesUtils.server,PropertiesUtils.version)
            print("This is server url: " + serverurl )
            
        return serverurl
    
    def getInteropWebServiceURL(self):
        
        if(PropertiesUtils.staging=="false" and PropertiesUtils.oci =="false"):
        
            serverurl = "http://%s:%s/interop/rest/%s" % (PropertiesUtils.server,PropertiesUtils.port, PropertiesUtils.epmapiversion)
            print("This is interopserver url: " + serverurl)
        
        else:
            serverurl = "https://%s/interop/rest/%s" % (PropertiesUtils.server,PropertiesUtils.epmapiversion)
            #stguser = PropertiesUtils.domain + "." + PropertiesUtils.user
            print("This is interopserver url: " + serverurl)
            
        return serverurl
    
    def getProfitURL(self):
        
        if(PropertiesUtils.staging=="false" and PropertiesUtils.oci =="false"):
        
            serverurl = "http://%s:%s/epm" % (PropertiesUtils.server, PropertiesUtils.port)
            print("This is server url: " + serverurl )
        
        else:
            serverurl = "https://%s/epm" % (PropertiesUtils.server)
            print("This is server url: " + serverurl )
            
        return serverurl
    

    
