import configparser
from certifi.core import contents
import os
import sys

config= configparser.RawConfigParser()
filepath = os.getcwd()

# from jenkins
#config.read("./PCMCS_Jet_DesignerCard/Configurations/config.ini")

#from local command line
#config.read("../Configurations/config.ini")

# from eclipse
config.read("../Configurations/config.ini") 

#print("arguments: ", sys.argv)
#print ("server is: " + sys.argv[1])


class ReadConfig:
    """
    args = sys.argv[3]
    argsaslist=args.split("-")
    print (argsaslist)
    """
    @staticmethod
    def getServer():
        #server = sys.argv[3]
        #serveraslist=server.split("-");
        """
        environment=str(ReadConfig.argsaslist[1])
        if (environment=="slcusinternal"):
            server="pcmcs-test-usinternalops65151.stg-epm.us1.oraclecloud.com"
        elif(environment=="slceprcs"):
            server="pcmcs-eprcsstage.stg-epm.us1.oraclecloud.com"
        elif(environment=="slcoci"):
            server="pcmcs-test-ocipcmcs.epm.us-ashburn-1.ocs.oc-test.com"
        else:
            server=environment   
        print("the server is: " +server)
        """
        server=config.get('common info', 'server')
        return server
        
    @staticmethod
    def getUser():
        
        #user=str(ReadConfig.argsaslist[2])
        #print("the user is: " +user)
        user=config.get('common info', 'user')
        return user
    
    @staticmethod
    def getPassword():
        #password=str(ReadConfig.argsaslist[3])
        #print("the password is: " +password)
        password=config.get('common info', 'password')
        return password
    
    @staticmethod
    def getPort():
        #port=str(ReadConfig.argsaslist[4])
        #print("the port is: " + port)
        port=config.get('common info', 'port')
        return port
    
    @staticmethod
    def getStaging():
        #staging=str(ReadConfig.argsaslist[5])
        #print("the staging is: " + staging)
        staging=config.get('common info', 'staging')
        return staging
    
    @staticmethod
    def getOCI():
        #oci=str(ReadConfig.argsaslist[6])
        #print("the oci is: " + oci)
        oci=config.get('common info', 'oci')
        return oci
    
    @staticmethod
    def getDomain():
        #domain=str(ReadConfig.argsaslist[7])
        domain=config.get('common info', 'domain')
        print("the domain is: " + domain)
        return domain
    
    @staticmethod
    def getEPMAPIVersion():
        epmapiversion=config.get('common info', 'epmapiversion')
        return epmapiversion
    @staticmethod
    def getVersion():
        version=config.get('common info', 'version')
        return version
    
    @staticmethod
    def getStatusCheckURL():
        checkstatusurl=config.get('common info', 'checkstatusurl')
        return checkstatusurl
    
    @staticmethod
    def getModelName():
        #modelname=str(ReadConfig.argsaslist[8])
        modelname=config.get('common info', 'modelName')
        print("the model name is: " + modelname)
        return modelname
    
    @staticmethod
    def getIMPPayLoad():
        imppayload=config.get('common info', 'impPayLoad')
        return imppayload
       
    @staticmethod
    def getAppName():
        #appname=str(ReadConfig.argsaslist[8])
        appname=config.get('common info', 'applicationName')
        print("the app name is: " + appname)
        return appname
    @staticmethod
    def getContents():
        contents=config.get('common info', 'contents')
        return contents
        
    @staticmethod
    def getBrowser():
        browser=config.get('common info', 'browser')
        return browser