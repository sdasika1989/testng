import logging
import os

class logGen:
    
    filepath = os.getcwd()
    print("this is path from logs folder: " + filepath)
    
    @staticmethod
    def logggen():
        for handler in logging.root.handlers[:]:
            logging.root.removeHandler(handler)
        #Modified the path for the file to pick dynamically from jenkins
        #logging.basicConfig(filename= ".//PCMCS_Jet_DesignerCard//Logs//executionlogs.log",
        #                format='%(asctime)s: %(levelname)s: %(message)s', datefmt='%m/%d/%Y %I:%M:%S %p')       
        
        #from command line
        #logging.basicConfig(filename= "..\\Logs\\executionlogs.log",
        #                format='%(asctime)s: %(levelname)s: %(message)s', datefmt='%m/%d/%Y %I:%M:%S %p')
        # from eclipse
        logging.basicConfig(filename= "..\\Logs\\executionlogs.log",
                        format='%(asctime)s: %(levelname)s: %(message)s', datefmt='%m/%d/%Y %I:%M:%S %p')
        logger=logging.getLogger()
        logger.setLevel(logging.INFO)
        return logger    
        #simple comment D:\JETUIPYTHON\Jet_UI_Python\Logs .\\Logs\\executionlogs.log
    
    
                        