import requests
from utilities.propertiesUtils import PropertiesUtils 
#import urllib.request, urllib.parse, urllib.error,base64
#import xml.etree.ElementTree as ET
#import json
3#import ssl
import os
from utilities.customLogger import logGen
from utilities.readProperties import ReadConfig

class FileUploadUtilities():
    logger=logGen.logggen()
    prop = PropertiesUtils()
    password = ReadConfig.getPassword()
    server = ReadConfig.getServer()
    port = ReadConfig.getPort()
    version = ReadConfig.getVersion()
    epmapiversion=ReadConfig.getEPMAPIVersion()
    staging = ReadConfig.getStaging()
    oci = ReadConfig.getOCI()
    user = ReadConfig.getUser()
    domain = ReadConfig.getDomain()
    
    
    stguser = domain + "." + user
    #fileName=prop.configs.get("fileName").data
    contents=ReadConfig.getContents()
    
    
    def uploadFileOverwrite(self,remoteFolder,modelName,fileName):
        
        if (FileUploadUtilities.listFiles(self,remoteFolder,fileName)):
            
            FileUploadUtilities.logger.info("Now the file deletion process is starting")
        
            if (FileUploadUtilities.deleteFile(self,remoteFolder,fileName)):
                
                if (FileUploadUtilities.uploadFile(self, remoteFolder,modelName, fileName)):
                    FileUploadUtilities.logger.info ("The file has been uploaded successfully")
                    
                else:
                    FileUploadUtilities.logger.info ("The file has not been uploaded successfully")
                    
        else:
            
            FileUploadUtilities.logger.info ("As there is no file exists upload process will start")
            
            if (FileUploadUtilities.uploadFile(self, remoteFolder, modelName, fileName)):
                
                FileUploadUtilities.logger.info ("The file has been uploaded successfully")
                
            else:
                FileUploadUtilities.logger.info ("The file has not been uploaded successfully")
          
        
    def uploadFile(self, remoteFolder, modelName, fileName):
        
        uploadFileURL= FileUploadUtilities.prop.getInteropWebServiceURL() + "/applicationsnapshots/" + fileName + "/%s" % (FileUploadUtilities.contents)
        #FileUploadUtilities.logger.info(uploadFileURL)
        #file = open('.\\TestData\\Models\\' + fileName ,'rb')
        #FileUploadUtilities.logger.info("test data path for picking models is working")
        #FileUploadUtilities.logger.info("the model into which template and data are used are: " + './PythonProject1/TestData/models/' + modelName + "/" + fileName)
        #filepath = os.getcwd()
        #file = open( filepath + '/TestData/models/' + modelName + "/" + fileName ,'rb')
        #from command line
        #file = open( './PCMCS_Jet_DesignerCard/TestData/models/' + modelName + "/" + fileName ,'rb')
        #from eclipse
        file = open( '../TestData/models/' + modelName + "/" + fileName ,'rb')
        FileUploadUtilities.logger.info("the model into which template and data are used are: " + './PythonProject1/TestData/models/' + modelName + "/" + fileName)
        templateData=file.read()
        file.close()
        #file_stats=os.stat('./PythonProject1/TestData/models/' + modelName + "/" + fileName)
        #file_stats=os.stat('..//TestData//Models//' + fileName)
        #FileUploadUtilities.logger.info(file_stats)
        #FileUploadUtilities.logger.info(f'File Size in Bytes is {file_stats.st_size}')
        #FileUploadUtilities.logger.info(f'File Size in MegaBytes is {file_stats.st_size / (1024 * 1024)}')    
        
        if(FileUploadUtilities.staging=="false"):
            response = requests.post(uploadFileURL, data=templateData, auth = (FileUploadUtilities.user, FileUploadUtilities.password))
            FileUploadUtilities.logger.info(response)
            
            
        else:
            response = requests.post(uploadFileURL, data=templateData, auth = (FileUploadUtilities.stguser, FileUploadUtilities.password))
            FileUploadUtilities.logger.info(response)
        
     
        response_body = response.json()
        
        if( response_body["status"] == 0):
            return True
            #print ("The file has been uploaded successfully")
        
        else:
            return False
            #print ("The file has been not uploaded successfully")
        

    def listFiles(self,remoteFolder,fileName):
        
        listFileUrl = FileUploadUtilities.prop.getInteropWebServiceURL() + "/applicationsnapshots"
        
        if(FileUploadUtilities.staging=="false"):
            response = requests.get(listFileUrl, auth = (FileUploadUtilities.user, FileUploadUtilities.password))
            #FileUploadUtilities.logger.info(response)
        
        else:
            response = requests.get(listFileUrl, auth = (FileUploadUtilities.stguser, FileUploadUtilities.password))
            #FileUploadUtilities.logger.info(response)
            
        response_body = response.json()
        items =response_body["items"]
        #FileUploadUtilities.logger.info(items)
        #print(len(items))
        #print (remoteFolder)
        #print (fileName)
        
        
        for i in range(len(items)):
            
            #print (items[i].get('name'))
            if (items[i].get('name') == remoteFolder + "/" + fileName):
                FileUploadUtilities.logger.info (items[i].get('name'))
                FileUploadUtilities.logger.info("remote folder is identified and file exists")
                return True
                break
                
            else:
                
                continue
        
        FileUploadUtilities.logger.info ("There is no file exists in the profitinbox folder")    
        return False
        
        
    def deleteFile(self, remoteFolder, fileName):
        
        deleteFileUrl= FileUploadUtilities.prop.getInteropWebServiceURL() +"/applicationsnapshots/"+ remoteFolder +"%5C"+ fileName               
        FileUploadUtilities.logger.info ("This is delete file url: " + deleteFileUrl)
        
        if(FileUploadUtilities.staging=="false"):
            response = requests.delete(deleteFileUrl, auth = (FileUploadUtilities.user, FileUploadUtilities.password))
            FileUploadUtilities.logger.info(response)
        
        else:
            response = requests.delete(deleteFileUrl, auth = (FileUploadUtilities.stguser, FileUploadUtilities.password))
            FileUploadUtilities.logger.info(response)
            
        response_body = response.json()
        
        if( response_body["status"] == 0):
            FileUploadUtilities.logger.info ("The file has been delete successfully")
            return True
            
        
        else:
            FileUploadUtilities.logger.info ("The file has been not deleted successfully")
            return False
         
            
#FileUploadUtilities.uploadFileOverwrite(print,"profitinbox","template.zip")
        
        
        
        
        
        
        
        
      