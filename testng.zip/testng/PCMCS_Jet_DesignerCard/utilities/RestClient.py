import requests
from utilities.customLogger import logGen

class RestClient:
    
    logger=logGen.logggen()
    
    def callDeleteService(self, url, username, password):
        
        response = requests.delete(url, auth = (username, password))
        return response
    
    def callGetService(self, url, username, password):
        
        response = requests.get(url, auth = (username, password))
        return response
    
    def callPostService(self, url, payload, username, password):
        
        response = requests.post(url, data=payload, auth = (username, password))
        return response