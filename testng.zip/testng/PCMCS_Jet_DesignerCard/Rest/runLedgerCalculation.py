import logging
import requests


from utilities.propertiesUtils import PropertiesUtils 
from utilities.customLogger import logGen
from utilities.RestClient import RestClient
from Rest.checkJobStatus import checkJobStatus

class RunLedgerCalculation():
    logger=logGen.logggen()
    
    def runLedgerCalculation(self):
        timeout = 500
        prop = PropertiesUtils()
        getJobStatus = checkJobStatus()
        pov = prop.configs.get("pov").data
        model = prop.configs.get("modelName").data
        staging = prop.configs.get("staging").data
        user = prop.configs.get("user").data
        password = prop.configs.get("password").data
        domain = prop.configs.get("domain").data
        checkstatus = prop.configs.get("checkstatusurl").data
        runCalcPayLoad = prop.configs.get("runCalcPayLoad").data
        stguser = domain + "." + user
        
        #ledger Calculation Job appending url
        ledurl = "/applications/%s/povs/%s/jobs/runLedgerCalculationJob" % (model, pov)
        
        ledjoburl = prop.getWebserviceurl() + ledurl
        RunLedgerCalculation.logger.info("The calculation job url is: " + ledjoburl)
    
        if(staging=="false"):
            response = RestClient.callPostService(self, ledjoburl, runCalcPayLoad, user, password)
            RunLedgerCalculation.logger.info(response)
        
        else:
            response = RestClient.callPostService(self, ledjoburl, runCalcPayLoad, stguser, password)
            RunLedgerCalculation.logger.info(response)
         
        response_body = response.json()
        assert response_body["statusMessage"] == "In Progress"
        jobName = response_body["details"]
        RunLedgerCalculation.logger.info ("These details are for Ledger Calculation Job: " + response_body["statusMessage"]  + " and "+  jobName )
        
        checkJobStatusUrl = prop.getWebserviceurl() + checkstatus + jobName
        RunLedgerCalculation.logger.info(checkJobStatusUrl)
        getJobStatus.checkJobStatus(checkJobStatusUrl)
    
       