import logging
import requests
import time


from utilities.propertiesUtils import PropertiesUtils 
from utilities.customLogger import logGen
from utilities.RestClient import RestClient
from utilities.readProperties import ReadConfig

class checkJobStatus():
    
    logger=logGen.logggen()
    def checkJobStatus(self,joburl):
        timeout = 3000
        prop = PropertiesUtils()
        staging = ReadConfig.getStaging()
        user = ReadConfig.getUser()
        password = ReadConfig.getPassword()
        domain = ReadConfig.getDomain()
        stguser = domain + "." + user
        
        
        checkJobStatusUrl = joburl
        checkJobStatus.logger.info(checkJobStatusUrl)
    
        for i in range(timeout):
        
                i = i + 25
                time.sleep(25)
        
                if (staging=="false"):
                    response =  RestClient.callGetService(self, checkJobStatusUrl, user, password)
                    response_body = response.json()
            
                else:
                    response = RestClient.callGetService(self, checkJobStatusUrl, stguser, password) 
                    response_body = response.json()
       
                if response_body["statusMessage"]=="In Progress":
                    checkJobStatus.logger.info("Job status is: " + response_body["statusMessage"])
                    continue
            
        
                elif response_body["statusMessage"]=="Success":
                    checkJobStatus.logger.info("Job status is: " + response_body["statusMessage"] )
                    break  
                
                assert response_body["statusMessage"]=="Success"
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                