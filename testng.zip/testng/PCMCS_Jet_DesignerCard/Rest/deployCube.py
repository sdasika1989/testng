import logging
import requests


from utils.propertiesUtils import PropertiesUtils 
from utils.customLogger import logGen
from utils.RestClient import RestClient
from common.checkJobStatus import checkJobStatus

class DeployCube():
    
    logger=logGen.logggen()
    def deployCube(self):
        prop = PropertiesUtils()
        timeout = 500
        getJobStatus = checkJobStatus()
        appName = prop.configs.get("applicationName").data
        depPayLoad = prop.configs.get("depPayLoad").data
        staging = prop.configs.get("staging").data
        user = prop.configs.get("user").data
        password = prop.configs.get("password").data
        domain = prop.configs.get("domain").data
        checkstatus = prop.configs.get("checkstatusurl").data
        
        stguser = domain + "." + user
        #deploy cube job appending url
        depurl="/applications/%s/jobs/ledgerDeployCubeJob" % (appName)
    
        depjoburl =  prop.getWebserviceurl() + depurl
        DeployCube.logger.info("The deploy cube job url is: " + depjoburl)
    
        if(staging=="false"):
            response = RestClient.callPostService(self, depjoburl, depPayLoad, user, password)
            DeployCube.logger.info(response)
        
        else:
            response = RestClient.callPostService(self, depjoburl, depPayLoad, stguser, password)
            DeployCube.logger.info(response)
        
        response_body = response.json()
        assert response_body["statusMessage"] == "In Progress"
        jobName = response_body["details"]
        DeployCube.logger.info ("These details are for deploy cube job: " + response_body["statusMessage"]  + " and "+  jobName )
    
        checkJobStatusUrl = prop.getWebserviceurl() + checkstatus + jobName
        DeployCube.logger.info(checkJobStatusUrl)
        getJobStatus.checkJobStatus(checkJobStatusUrl)
    
            