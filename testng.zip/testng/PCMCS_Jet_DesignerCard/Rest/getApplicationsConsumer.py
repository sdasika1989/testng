import logging
import requests
import json


from utilities.propertiesUtils import PropertiesUtils 
from utilities.customLogger import logGen
from utilities.RestClient import RestClient
from utilities.readProperties import ReadConfig

class GetApplicationsConsumer():
    logger=logGen.logggen()
        
    def getApplicationNames(self):
        prop = PropertiesUtils()
        staging = ReadConfig.getStaging()
        user = ReadConfig.getUser()
        password = ReadConfig.getPassword()
        domain = ReadConfig.getDomain()
        stguser = domain + "." + user
        
        
        
        getAppUrl = prop.getWebserviceurl() + "/applications"
        GetApplicationsConsumer.logger.info("The Get Applications API URL is: " + getAppUrl  )
    
        if(staging=="false"):
            response =  RestClient.callGetService(self, getAppUrl, user, password)
            
            GetApplicationsConsumer.logger.info(response)
        
        else:
            response = RestClient.callGetService(self, getAppUrl, stguser, password)
            
            GetApplicationsConsumer.logger.info(response)
         
        response_body = response.json()
        items =response_body["items"]
        
        GetApplicationsConsumer.logger.info(items)
        
        
        if (items != []): 
            
           
            #GetApplicationsConsumer.logger.info(items[0])
            serverAppName = items[0].get('name')
            GetApplicationsConsumer.logger.info("The existing application in the server is: " + serverAppName)
            return serverAppName
        
        else:
            GetApplicationsConsumer.logger.info("There is no application to fetch the name in the server")
        

#GetApplicationsConsumer.getApplicationNames(print)       
        
        


        

        
