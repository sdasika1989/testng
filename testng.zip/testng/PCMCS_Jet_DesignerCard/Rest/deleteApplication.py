import logging
import requests


from utilities.propertiesUtils import PropertiesUtils 
from Rest.getApplicationsConsumer import GetApplicationsConsumer 
from utilities.customLogger import logGen
from utilities.RestClient import RestClient
from Rest.checkJobStatus import checkJobStatus
from utilities.readProperties import ReadConfig

class DeleteApplication():
    
    logger=logGen.logggen()
    
    def deleteApplication(self):
        timeout = 500
        prop = PropertiesUtils()
        getAppName = GetApplicationsConsumer()
        getJobStatus = checkJobStatus()
        #appName = prop.configs.get("applicationName").data
        staging = ReadConfig.getStaging()
        user = ReadConfig.getUser()
        password = ReadConfig.getPassword()
        domain = ReadConfig.getDomain()
        checkstatus = ReadConfig.getStatusCheckURL()
        stguser = domain + "." + user

        serverAppName = getAppName.getApplicationNames()
        
        #print (serverAppName)
       
        if (serverAppName != None):
            
            delAppUrl = prop.getWebserviceurl() + "/applications/%s" % (serverAppName) 
            DeleteApplication.logger.info("Application exists and delete job will start: " + delAppUrl)  
            
            if(staging=="false"):
                response = RestClient.callDeleteService(self, delAppUrl, user, password)
                DeleteApplication.logger.info(response)
        
            else:
                response = RestClient.callDeleteService(self, delAppUrl, stguser, password)
                DeleteApplication.logger.info(response)
                
            response_body = response.json()
            assert response_body["statusMessage"] == "In Progress"
            jobName = response_body["details"]
        
            DeleteApplication.logger.info ("These details are for delete application job: " + response_body["statusMessage"]  + " and "+  jobName )
            checkJobStatusUrl = prop.getWebserviceurl() + checkstatus + jobName
            getJobStatus.checkJobStatus(checkJobStatusUrl)
            
        else:
            DeleteApplication.logger.info ("There is no application to delete in the server")
            
        
#DeleteApplication.deleteApplication(print)        
            
        
            