import requests


from utilities.propertiesUtils import PropertiesUtils 
from utilities.customLogger import logGen
from utilities.RestClient import RestClient
from Rest.checkJobStatus import checkJobStatus

class DataLoad():
    
    logger=logGen.logggen()
    
    def dataLoad(self):
        prop = PropertiesUtils()
        timeout = 500
        getJobStatus = checkJobStatus()
        staging = prop.configs.get("staging").data
        user = prop.configs.get("user").data
        password = prop.configs.get("password").data
        domain = prop.configs.get("domain").data
        checkstatus = prop.configs.get("checkstatusurl").data
        loadDataPayLoad = prop.configs.get("loadDataPayLoad").data
        appName = prop.configs.get("applicationName").data
        stguser = domain + "." + user
        
        
        # data load job appending url
        loadurl = "/applications/%s/jobs/essbaseDataLoadJob" % (appName)
        
        dataloadjoburl = prop.getWebserviceurl() + loadurl
        DataLoad.logger.info("The data load job url is: " + dataloadjoburl)
    
        if(staging=="false"):
            response = RestClient.callPostService(self, dataloadjoburl, loadDataPayLoad, user, password)
            DataLoad.logger.info(response)
        
        else:
            response = RestClient.callPostService(self, dataloadjoburl, loadDataPayLoad, stguser, password)
            DataLoad.logger.info(response)
        
        response_body = response.json()
        assert response_body["statusMessage"] == "In Progress"
        jobName = response_body["details"]
        DataLoad.logger.info ("These details are for data load job: " + response_body["statusMessage"]  + " and "+  jobName )
    
        checkJobStatusUrl = prop.getWebserviceurl() + checkstatus + jobName
        DataLoad.logger.info(checkJobStatusUrl)
        getJobStatus.checkJobStatus(checkJobStatusUrl)
    
        
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
    