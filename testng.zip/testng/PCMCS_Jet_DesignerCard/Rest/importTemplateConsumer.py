import logging
import requests


from utilities.propertiesUtils import PropertiesUtils 
from utilities.customLogger import logGen
from utilities.RestClient import RestClient
from Rest.checkJobStatus import checkJobStatus
from utilities.readProperties import ReadConfig

class ImportTemplate():
    logger=logGen.logggen()
    
    def importTemplate(self):
        
        timeout = 500
        getJobStatus = checkJobStatus()
        prop = PropertiesUtils()
        appName = ReadConfig.getAppName()
        password = ReadConfig.getPassword()
        checkstatus = ReadConfig.getStatusCheckURL()
        impPayLoad = ReadConfig.getIMPPayLoad()
        staging = ReadConfig.getStaging()
        user = ReadConfig.getUser()
        domain = ReadConfig.getDomain()
        stguser = domain + "." + user
            
        # import template job appending url
        impurl="/applications/%s/jobs/templateImportJob" % (appName)  
        
        #This is Import Template Section
     
        impjoburl = prop.getWebserviceurl() + impurl
        ImportTemplate.logger.info("The import template job url is: " + impjoburl)
    
        if(staging=="false"):
            response = RestClient.callPostService(self, impjoburl, impPayLoad, user, password)
            
            ImportTemplate.logger.info(response)
        
        else:
            response = RestClient.callPostService(self, impjoburl, impPayLoad, stguser, password)
            
            ImportTemplate.logger.info(response)
        
        response_body = response.json()
        assert response_body["statusMessage"] == "In Progress"
        jobName = response_body["details"]
        ImportTemplate.logger.info ("These details are for import template job: " + response_body["statusMessage"]  + " and "+  jobName )
    
        checkJobStatusUrl = prop.getWebserviceurl() + checkstatus + jobName
        ImportTemplate.logger.info(checkJobStatusUrl)
        getJobStatus.checkJobStatus(checkJobStatusUrl) 
        
        
        
        
        
        
        
        
        
            
        