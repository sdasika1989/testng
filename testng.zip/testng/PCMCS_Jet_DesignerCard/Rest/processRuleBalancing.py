import logging
import requests
import json
import filecmp
#from jsondiff import diff-

from utilities.propertiesUtils import PropertiesUtils
from utilities.customLogger import logGen
from utilities.RestClient import RestClient

class ProcessRuleBalancing():
    
    logger=logGen.logggen()
    
        
    def processRuleBalancing(self):
                   
        prop = PropertiesUtils()
        pov = prop.configs.get("pov").data
        appName = prop.configs.get("applicationName").data
        staging = prop.configs.get("staging").data
        oci = prop.configs.get("oci").data
        user = prop.configs.get("user").data
        password = prop.configs.get("password").data
        domain = prop.configs.get("domain").data
        actualFilePath=prop.configs.get("actualFilePath").data
        expectedFilePath=prop.configs.get("expectedFilePath").data
        stguser = domain + "." + user
        
        # rule balancing job appending url
        rulebalurl = "/applications/%s/povs/%s/ruleBalance" % (appName, pov)
        
        rulebaljoburl = prop.getWebserviceurl() + rulebalurl
        ProcessRuleBalancing.logger.info("The process rule balancing url is: " + rulebaljoburl)
    
        if(staging=="false"):
            response = RestClient.callGetService(self, rulebaljoburl, user, password)
            ProcessRuleBalancing.logger.info(response)
        
        else:
            response = RestClient.callGetService(self, rulebaljoburl, stguser, password)
            ProcessRuleBalancing.logger.info(response)
         
        response_body = response.json()
        ProcessRuleBalancing.logger.info (response_body["items"])
       
        #with open('D:\sample\PythonProject1\\Logs\\' + pov + '.txt', 'w') as  json_file:
        with open('./PythonProject1/Logs/' + pov + '.txt', 'w') as  json_file:
            json.dump(response_body["items"],  json_file, sort_keys = True)
            
                
        #matStatus = bool(diff(actualFilePath, expectedFilePath))  
        matStatus = bool(filecmp.cmp(actualFilePath, expectedFilePath))
        
                
        ProcessRuleBalancing.logger.info("The paths are: " + actualFilePath + " " + expectedFilePath)
        
        ProcessRuleBalancing.logger.info(matStatus)
        
        if (matStatus == True):
            
            ProcessRuleBalancing.logger.info("Numbers are matching")
            
            
        else:
            
            ProcessRuleBalancing.logger.info ("Numbers are not matching")  
              
        assert matStatus == True
        
#ProcessRuleBalancing.processRuleBalancing(print)
        
        