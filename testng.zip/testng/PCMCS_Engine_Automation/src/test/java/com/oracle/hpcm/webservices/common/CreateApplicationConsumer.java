package com.oracle.hpcm.webservices.common;

public class CreateApplicationConsumer {

}
