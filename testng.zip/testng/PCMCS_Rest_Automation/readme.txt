Command to run maven

mvn -s settings.xml -f pom.xml -Dversion=v1 -Dserver=slc10zwb.us.oracle.com -Dport=9000 -Duser=epm_default_cloud_admin -Dpassword=password1 -Dstaging=false -Ddomain=xyz -Dtimeout=1000 
