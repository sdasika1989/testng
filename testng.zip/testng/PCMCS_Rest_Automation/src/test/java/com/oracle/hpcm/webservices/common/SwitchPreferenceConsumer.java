package com.oracle.hpcm.webservices.common;

import java.util.HashMap;
import java.util.logging.Logger;

import org.json.simple.parser.ParseException;

import com.oracle.hpcm.utils.JAXRestClient;
import com.oracle.hpcm.utils.JSONResultParser;
import com.oracle.hpcm.utils.PropertiesUtils;
import com.oracle.hpcm.utils.ResultObject;
import com.oracle.hpcm.utils.UserObject;

public class SwitchPreferenceConsumer 
{

	private String url;
	private String password;
	private String user;
	private String response;
	public static Logger logger = Logger.getLogger("");

	public SwitchPreferenceConsumer()
	{
		UserObject userCredentials = PropertiesUtils.getUserObject();
		user = userCredentials.getUserName();
		password = userCredentials.getPassword();
		url = PropertiesUtils.getWebServiceURL()+"/applications/";
	}
	
	public ResultObject switchPreference(String appName, String  preferenceName,String preferenceValue) throws ParseException{
		HashMap<String, String> hashMap = new HashMap<String, String>();
		hashMap.put("preferenceName", ""+ preferenceName);
		hashMap.put("preferenceValue", ""+ preferenceValue);
		this.response = JAXRestClient.callPostService(url + appName + "/switchPreference/", user, password, hashMap);
		logger.info("Response: "+ this.response);
		JSONResultParser result = new JSONResultParser(this.response);
		return result.getResultObject();
	}

}
