package com.oracle.hpcm.wstests;

import java.io.File;
import java.util.Iterator;
import java.util.Properties;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.apache.commons.io.FileUtils;
import org.apache.commons.io.IOCase;
import org.apache.commons.io.filefilter.IOFileFilter;
import org.apache.commons.io.filefilter.SuffixFileFilter;
import org.testng.Assert;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.oracle.hpcm.utils.EPMAutomateUtility;
import com.oracle.hpcm.utils.PropertiesUtils;
import com.oracle.hpcm.utils.ResultObject;
import com.oracle.hpcm.utils.UserObject;
import com.oracle.hpcm.webservices.common.DeleteApplicationConsumer;
import com.oracle.hpcm.webservices.common.GetApplicationsConsumer;
import com.oracle.hpcm.webservices.common.GetTaskStatusByProcessNameConsumer;
import com.oracle.hpcm.webservices.common.ProcessImportTemplateConsumer;
import com.oracle.hpcm.webservices.common.SwitchPreferenceConsumer;


public class SwitchInstallationPreference 

{
	private String mlAppName;
	public static Logger logger = Logger.getLogger("MLTestFixture");
	public static int timeout;

	@BeforeClass
	public void setUp() throws Exception {
		logger.log(Level.INFO, "***********Test Environment Setup***********");
		System.setProperty("http.proxyHost", "127.0.0.1");
		System.setProperty("https.proxyHost", "127.0.0.1");
		System.setProperty("http.proxyPort", "8888");
		System.setProperty("https.proxyPort", "8888");
		Properties prop = System.getProperties();
		System.out.println(System.getProperty("domain"));
		PropertiesUtils.processGlobalProperties(prop);
		PropertiesUtils.processModelProperties(prop);
		UserObject userCredentials = PropertiesUtils.getUserObject();
		timeout = PropertiesUtils.getTimeout();
		String user = userCredentials.getUserName();
		String password = userCredentials.getPassword();
		System.out.println(user + " " + password);
		//BeginTest.processArgs(args);
		mlAppName = "ML";
		
		for (String appName : new GetApplicationsConsumer().getApplicationsNames()) {
            logger.info("Deleteing app " + appName);
            ResultObject ro = new DeleteApplicationConsumer().deleteApp(appName);
            Assert.assertTrue(ro.isResult(), "Deletion of app failed to create a deletion job.");
            GetTaskStatusByProcessNameConsumer getStatusObj = new GetTaskStatusByProcessNameConsumer();
            Assert.assertTrue(getStatusObj.waitForJobToFinish(ro.getText(), timeout), "App deletion job failed to finish successfully.");

        }
        /*		Assert.assertTrue("EPMA Import Assert.failed.", epmaDeployer.deploy(mlAppName));
		LCMImporter.execute(mlAppName);*/
        //SFTPUtil.transfer(new File("./models/ML/template.zip"));
        boolean templateFileName = EPMAutomateUtility.uploadFileOverwrite("./models/ML/", "template.zip", "profitinbox");
        Assert.assertTrue(templateFileName, "File Transfer Assert.failed.");
        ProcessImportTemplateConsumer importAppObj = new ProcessImportTemplateConsumer();
        ResultObject result = importAppObj.importTemplate(mlAppName, "Created by webservice automation.",
                "PROFITABILITY_WEB_APP", "EssbaseCluster-1",
                "Default Application Group",
                "template.zip", true);
        Assert.assertTrue(result.isResult());
        String jobName = result.getText();
        Assert.assertNotNull(jobName);
        GetTaskStatusByProcessNameConsumer getStatusObj = new GetTaskStatusByProcessNameConsumer();
        Assert.assertTrue(getStatusObj.waitForJobToFinish(jobName, timeout));
	}

	@Test(enabled = true, priority = 1, description = "Target Webservice = SwitchPreferences, assert that SwitchPreferenceJob works.")
	public void testswitchPreference() throws Exception {
		logger.log(Level.INFO,
				"***********testswitchPreference***********");
		SwitchPreferenceConsumer WSObj = new SwitchPreferenceConsumer();
		ResultObject result = WSObj.switchPreference(mlAppName, "Beta.3", "N");
		Assert.assertTrue(result.isResult());
		String details = result.getText();
		Assert.assertNotNull(details);
		Assert.assertTrue(result.getText().contentEquals("Application: ML preferences updated successfully."));
		logger.log(Level.INFO,
				"Beta.3 value has been updated");
	}

	@AfterMethod
	public void afterMethod(ITestResult result)
	{
		if (result.isSuccess()) 
		{
			logger.info("Test case " + result.getMethod().getMethodName() + " is a pass.");
		} 
		else 
		{
			if (result.getStatus() == ITestResult.FAILURE)
			{
				logger.severe("Test case " + result.getMethod().getMethodName() + " is a fail.");
				//Throwable ex = result.getThrowable();
				//logger.log(Level.SEVERE,"Exception : "+ex.getMessage());
			}
			//logger.info("Test case " + result.getMethod().getMethodName() + " is a pass.");
		}
	}



}