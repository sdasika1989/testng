package com.oracle.pcmcs.enums;

public class EnumsClass {
	public static enum ANALYTICS_ITEM_TYPE{
		WHALE,
		SCATTER,
		ANALYSIS_VIEW
	}
}
