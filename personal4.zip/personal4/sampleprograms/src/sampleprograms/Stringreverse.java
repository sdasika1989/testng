package sampleprograms;

public class Stringreverse 
{
	public static String reverseString(String str)
	{  
		StringBuilder sb=new StringBuilder(str);  
		sb.reverse();  
		return sb.toString();  
	}  

	public static void main(String[] args)
	{  
		System.out.println(Stringreverse.reverseString("mynameiskhan"));  
		System.out.println(Stringreverse.reverseString("Iamsonoojaiswal"));      
	}  

}
