package sampleprograms;

import java.util.Arrays;

public class BinarySearch {

	public static void main(String[] args) 
	{
		int arr[] = {10,20,30,50};
		int key = 10;
		
		//Arrays.sort(arr) - If the array is not in ascending order
		/*
		 We basically ignore half of the elements just after one comparison.
		Compare x with the middle element.
		If x matches with middle element, we return the mid index.
		Else If x is greater than the mid element, then x can only lie in right half subarray after the mid element. So we recur for right half.
		Else (x is smaller) recur for the left half.
		 */
		int result = Arrays.binarySearch(arr, key);
		if(result<0)
		{
			System.out.println("element is not found");
		}
		else
		{
			System.out.println("element is found at: " + key + " and result is: " + result);
		}

	}

}


/* 
 Scrum Ceremonies
 
 scrum ceremonies provide the framework for teams to get work done in a 
 structured manner, help to set expectations, empower the team to collaborate 
 effectively, and ultimately drive results
 
 * Prodcut Back Log 

	A product backlog is a prioritized list of work for the development team that
	is derived from the roadmap and its requirements. The most important items are
	shown at the top of the product backlog so the team knows what to deliver first.
	
	
	Sprint Back Log
	
	A sprint backlog is the set of items that a cross-functional product team selects 
	from its product backlog to work on during the upcoming sprint. Typically the team 
	will agree on these items during its sprint planning session. In fact, the sprint 
	backlog represents the primary output of sprint planning.
	
	https://thedigitalprojectmanager.com/scrum-ceremonies-made-simple/
	
	https://www.projectmanager.com/blog/burndown-chart-what-is-it
	
	Sprint Velocity
	
	Velocity is a measure of the amount of work a Team can tackle during a single 
	Sprint and is the key metric in Scrum. Velocity is calculated at the end of the 
	Sprint by totaling the Points for all fully completed User Stories.
	
	Definition of Done
	Scrum defines the Definition of Done in pretty simple terms: it's the acceptance 
	criteria that are common to every single user story. ... They work in sprints, 
	and need some way of deciding whether a user story is actually finished.
	
	*/
	
	

