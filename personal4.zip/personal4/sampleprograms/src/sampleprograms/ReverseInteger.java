package sampleprograms;

public class ReverseInteger {


	public static void main(String[] args) 
	{
		int num =1234;
		int reveresed =0;
		
		for (int i=1; i<=4; i++)
		//while (num !=0)
		{
			int digit = num%10;
			reveresed = reveresed * 10 + digit;
			num /=10;
		}
		
		
		System.out.println(reveresed);

	}

}
