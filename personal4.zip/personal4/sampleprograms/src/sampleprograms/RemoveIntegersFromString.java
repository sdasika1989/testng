package sampleprograms;

import java.util.Scanner;

public class RemoveIntegersFromString {

	public static void main(String[] args) 
	{
		String sc = "hhhttthh123jjj123213123fdsfsdfdsfsdf123456";
	    String sc1; // Variable 'inp',for storing the input
	    sc1 = sc.replaceAll("[0123456789]",""); // .replaceAll(),function used to replace. 
	    System.out.println(sc1);
	}
}
