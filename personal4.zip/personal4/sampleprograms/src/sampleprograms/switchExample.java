package sampleprograms;

public class switchExample 
{

	public static void main(String[] args) 
	{
		
		int number = 30;
		
		switch(number)
		{
		case 10:
			System.out.println("the number is: " + number);
			break;
		case 20:
			System.out.println("the number is: " + number);
			break;
		default:
			System.out.println("not is 10 and 20");
		}
	}

}
