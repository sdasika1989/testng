package sampleprograms;
import java.util.*;
public class RemoveDuplicateIntegers 
{
	
	static void removeDupIntheArray(int[] ints)
	{
		LinkedHashSet<Integer> setString = new LinkedHashSet<>();
		
		System.out.println(ints.length);
		
		for(int i=0; i<=ints.length-1;i++)
		{
			setString.add(ints[i]);
		}
		
		for (Integer string:setString)
		{
			System.out.print(string);
		}
	}

	public static void main(String[] args)
	{
		int[] inte = {1,2,3,4,5,6,5,4,3,2,1};
		removeDupIntheArray(inte);
	}

}
