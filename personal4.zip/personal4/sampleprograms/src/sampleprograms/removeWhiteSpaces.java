package sampleprograms;

public class removeWhiteSpaces {

	public static void removeWhiteSpace(String str) 
	{
		str = str.replaceAll(" ", "");
		System.out.println(str);
	}
	public static void main(String[] args) 
	{
		String str = "remove white spaces for the string";
		removeWhiteSpace(str);
	}

}
