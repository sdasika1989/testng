package sampleprograms;

import java.util.regex.Pattern;
public class ReverseString {
	public static void main(String[] args) 
	{
		String s1 = "This is Vijay and Manju is my wife";	
		System.out.println(reverse(s1));
	}
	static String reverse(String word){

		Pattern pattern = Pattern.compile(" ");
		String[] temp = pattern.split(word);

		String result ="";

		for(int i=0;i<temp.length;i++)
		{
			if(i==temp.length-1)
			{
				result = temp[i]+result;
			}
			else
				result = " "+temp[i]+result;
		}
		return result;

	}
}
